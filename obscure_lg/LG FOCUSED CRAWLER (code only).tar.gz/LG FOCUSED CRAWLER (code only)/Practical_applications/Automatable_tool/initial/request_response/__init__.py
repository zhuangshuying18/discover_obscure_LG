
import json
from selenium.webdriver.support.ui import Select
import random

import requests

import time
import datetime
import csv
import mechanize
## With the above interface information about VPs, we run ./\_init\_.py to translate ping measurement requests into the action of filling in the input fields of the corresponding form element with specific values
def pingmeasurement(templatefile,keywordmatchfile,output):
    dicttext={}
    targetip = '112.124.15.132'
    f = open(templatefile, encoding='utf-8')
    res = f.read()
    from collections import OrderedDict
    data = json.loads(res, object_pairs_hook=OrderedDict)
    for key in data:
        tem = data[key]['Template']
        for form in data[key]:
            if (form != 'Template'):
                if tem==1:
                    if('ping' in data[key][form]['cmd'][1] ):
                        dicttext[key] = [form, 'cmd=select=ping','host=text='+targetip,[]]
                    elif ('ping4' in data[key][form]['cmd'][1]):
                        dicttext[key] = [form, 'cmd=select=ping4', 'host=text=' + targetip, []]
                elif (tem == 3):
                    listrouter=[]
                    for rse in data[key][form]['router'][1]:
                        listrouter.append('router=select='+rse)
                    if ('ping' in data[key][form]['command'][1]):
                        dicttext[key] = [form, 'command=radio=ping', 'query=text=' + targetip,listrouter]
                    elif ('ping4' in data[key][form]['command'][1]):
                        dicttext[key] = [form, 'command=radio=ping4', 'query=text=' + targetip,listrouter]
                elif (tem == 4):
                    listrouter = []
                    for rse in data[key][form]['routers'][1]:
                        listrouter.append('routers=select=' + rse)
                    if ('ping' in data[key][form]['query'][1]):
                        dicttext[key] = [form, 'query=select=ping', 'parameter=text=' + targetip, listrouter]
                    elif ('ping4' in data[key][form]['query'][1]):
                        dicttext[key] = [form, 'query=select=ping4', 'parameter=text=' + targetip, listrouter]
                elif (tem == 6):
                    listrouter = []
                    for rse in data[key][form]['router'][1]:
                        listrouter.append('router=select=' + rse)
                    if ('8' in data[key][form]['query'][1]):
                        dicttext[key] = [form, 'query=radio=8', 'arg=text=' + targetip, listrouter]

                elif (tem == 7):
                    listrouter = []
                    for rse in data[key][form]['router'][1]:
                        listrouter.append('router=select=' + rse)
                    if ('ping' in data[key][form]['query'][1]):
                        dicttext[key] = [form, 'query=radio=ping', 'addr=text=' + targetip, listrouter]
                    elif ('ping4' in data[key][form]['query'][1]):
                        dicttext[key] = [form, 'query=radio=ping4', 'addr=text=' + targetip, listrouter]


                elif (tem == 8):
                    listrouter = []
                    for rse in data[key][form]['server'][1]:
                        listrouter.append('server=select=' + rse)
                    if ('ping' in data[key][form]['action'][1]):
                        dicttext[key] = [form, 'action=select=ping', 'args=text=' + targetip, listrouter]
                    elif ('ping4' in data[key][form]['action'][1]):
                        dicttext[key] = [form, 'action=select=ping4', 'args=text=' + targetip, listrouter]
                elif (tem == 9):
                    if ('ping' in data[key][form]['cmd'][1]):
                        dicttext[key] = [form, 'cmd=select=ping', 'req=text=' + targetip, []]
                    elif ('ping4' in data[key][form]['cmd'][1]):
                        dicttext[key] = [form, 'cmd=select=ping4', 'req=text=' + targetip, []]

    ###interface information about VPs (from keyword matching)
    listrouter = ['network', 'site', 'RTR', 'cityId', 'server', 'router', 'routers', 'routers[]', 'lg_router',
                  'site_name', 'source', 'node', 'routerlocation', 'routername',
                  'lsrr', 'routeserver', 'node_select', 'location', 'datacenter', 'hostname'
                  ]
    f = open(keywordmatchfile,encoding='utf-8')
    res = f.read()
    from collections import OrderedDict
    data = json.loads(res, object_pairs_hook=OrderedDict)
    for key in data:
        for formnum in data[key]:
            for controlname in data[key][formnum]:
                controltype = data[key][formnum][controlname][0]
                possibleitem = data[key][formnum][controlname][1]
                for item in possibleitem:
                    if ('ping' in item.lower()):
                        dicttext[key] = [formnum, controlname + '='+controltype +'=' + item]
                        break

    for key in data:
        for formnum in data[key]:
            if (key in dicttext and formnum == dicttext[key][0]):
                tagIP = 0
                tagrouter = 0

                for controlname in data[key][formnum]:
                    controltype = data[key][formnum][controlname][0]
                    if ( controltype == 'text'):
                        dicttext[key].append(controlname +'='+controltype+'=' + targetip)
                        tagIP = 1
                        break
                if (tagIP == 0):
                    dicttext[key].append('')

                for controlname in data[key][formnum]:
                    if (controlname in listrouter):
                        controltype = data[key][formnum][controlname][0]
                        possibleitem = data[key][formnum][controlname][1]
                        list1 = []
                        for item in possibleitem:
                            list1.append(controlname + '='+controltype+'=' + item)
                        dicttext[key].append(list1)
                        tagrouter = 1
                if (tagrouter == 0):
                    dicttext[key].append([])



    ##the action of filling in the input fields of the corresponding form element with specific values
    file = open(output, 'w')
    dictnum = {}
    for key in dicttext:
        if (dicttext[key][2] != ''):
            dictnum[key] = ''
            if (dicttext[key][3] == []):
                file.writelines(
                    key + ',|zsy|' + dicttext[key][0] + ',|zsy|' + dicttext[key][1] + ',|zsy|' + dicttext[key][
                        2] + ',|zsy| ' + '\n')
            else:
                for item in dicttext[key][3]:
                    file.writelines(
                        key + ',|zsy|' + dicttext[key][0] + ',|zsy|' + dicttext[key][1] + ',|zsy|' + dicttext[key][
                            2] + ',|zsy|' + item + '\n')
    print(len(dictnum))

#In addition to the above interface information, there are some other interface information that are extracted by using BeautifulSoup.
def pingmeasurementbs(keywordmatchbs,output):
    dicttext = {}
    targetip = '112.124.15.132'
    f = open(keywordmatchbs,encoding='utf-8')
    res = f.read()  # 读文件
    from collections import OrderedDict
    data = json.loads(res, object_pairs_hook=OrderedDict)
    for key in data:
        dicttext[key] = {}
        for formnum in data[key]:
            for controllist in data[key][formnum]:
                controlvalue = controllist[6]
                controltext = controllist[5]
                controlid = controllist[1]
                controltype = controllist[2]
                controlonclick = controllist[3]
                tag = 0
                for item in controlvalue:
                    if ('ping' in item.lower()):
                        tag = 1
                        if (formnum not in dicttext[key]):
                            if (controlid != ''):
                                dicttext[key][formnum] = [controlid + '=' + controltype + '=' + item]
                if (tag == 0):
                    for item in controltext:
                        if ('ping' == item.lower() and controltype == 'button'):
                            ##button
                            dicttext[key][formnum] = [controlonclick + '=' + controltype + '=' + item]

    print(dicttext)
    for key in data:
        for formnum in data[key]:
            if (key in dicttext and formnum in dicttext[key]):
                for controllist in data[key][formnum]:
                    controltype = controllist[2]
                    controlid = controllist[1]
                    controltext = controllist[4]

                    if (controltype == 'text' and 'IP' in controltext and controlid != ''):
                        dicttext[key][formnum].append(controlid + '=' + controltype + '=' + targetip)
                        print('in')
                        break

    print(dicttext)
    file = open(output, 'w')
    dictnum = {}
    for key in dicttext:
        for formnum in dicttext[key]:
            try:
                file.writelines(
                    key + ',|zsy|' + formnum + ',|zsy|' + dicttext[key][formnum][0] + ',|zsy|' + dicttext[key][formnum][
                        1] + ',|zsy| ' + '\n')
            except IndexError as e:
                continue
    print(len(dictnum))


def issueping(i):

    #record each ping measurement request of asking each VP to ping a controlled machine
    dicturl = []
    #record each URL
    dicturlinfo={}
    file1 = open('pingcmd.csv', 'r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    for row in csv_reader1:
        dicturl.append(','.join(row))
        dicturlinfo[','.join(row).split(',|zsy|')[0]]=''
    file1 = open('pingseedcmd.csv', 'r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    for row in csv_reader1:
        dicturl.append(','.join(row))
        dicturlinfo[','.join(row).split(',|zsy|')[0]] = ''

    random.shuffle(dicturl)


    #sometimes, there may exist errors when we visit http://???,  but we can get html file by visiting https://???
    dicturlcontent = {}
    file1 = open( '../../../../Classification procedure/Get relevant URLs/initial/LGallcontent.csv', 'r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    for row in csv_reader1:
        urlpre = ','.join(row).split(',|zhuangshuying|')[0]
        try:
            urlnew = ','.join(row).split(',|zhuangshuying|')[1]
        except IndexError as e:
            continue
        if ( urlpre not in dicturlinfo):
            continue
        dicturlcontent[urlpre] = urlnew

    from selenium import webdriver
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')

    driver = webdriver.Chrome(chrome_options=chrome_options)

    driver.set_page_load_timeout(150)
    driver.set_script_timeout(150)
    f1 = open('ping_resulls_'+str(i)+'.csv', 'a')
    f2 = open('ping_errors_'+str(i)+'.csv', 'a')

    for num in range(0, len(dicturl)):
        time1=''
        time2=''
        cmd = dicturl[num]
        cmdlist = cmd.split(',|zsy|')
        print(cmdlist)
        if (cmdlist[0] in dicturlcontent):
            try:
                url=dicturlcontent[cmdlist[0]]
                time1 = str(datetime.datetime.now())
                driver.get(url)
                form = driver.find_elements_by_tag_name('form')[int(cmdlist[1])]
                for m in range(2,len(cmdlist)):
                    if(cmdlist[m]!=' '):
                        name=cmdlist[m].split('=')[0]
                        type=cmdlist[m].split('=')[1]
                        value=cmdlist[m].split('=')[2]
                        if(type=='radio'):
                            elem= driver.find_elements_by_name(name)
                            for i in elem:
                                if i.get_attribute('value')==value:
                                    if (not i.is_selected()):
                                        i.click()
                                        time.sleep(10)
                                    break
                        elif (type == 'checkbox'):
                            elem = driver.find_elements_by_name(name)
                            for i in elem:
                                if i.get_attribute('value') == value:
                                    if (not i.is_selected()):
                                        i.click()
                                        time.sleep(10)
                                    break
                                else:
                                    if (i.is_selected()):
                                        i.click()

                        elif(type=='select'):
                            selector = Select(driver.find_element_by_name(name))
                            selector.select_by_value(value)
                        else:
                            elem = driver.find_element_by_name(name)
                            elem.clear()
                            elem.send_keys(value)


                form.submit()
                time.sleep(5)
                brr = str(driver.page_source.replace('\n', ' ').replace('\t', ' '))
                time2 = str(datetime.datetime.now())
                f1.writelines(',|zsy|'.join(
                        cmdlist) + ',|zsy1|' + time1 + ',|zsy1|' + time2 + ',|zhuangshuying|' + brr + '\n')
                f1.flush()


            except Exception as e:
                time2 = str(datetime.datetime.now())
                f2.writelines(',|zsy|'.join(cmdlist) + ',|zsy1|' + time1 + ',|zsy1|' + time2 + ',|zhuangshuying|' + str(
                    e).replace('\n', ' ').replace('\t', ' ') + '\n')
                f2.flush()
                continue
    driver.quit()





def issuepingbs(i):
    # record each ping measurement request of asking each VP to ping a controlled machine
    dicturl = []
    # record each URL
    dicturlinfo={}
    file1 = open('pingcmdbs.csv', 'r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    for row in csv_reader1:
        dicturl.append(','.join(row))
        dicturlinfo[','.join(row).split(',|zsy|')[0]] = ''
    file1 = open('pingseedcmdbs.csv', 'r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    for row in csv_reader1:
        dicturl.append(','.join(row))
        dicturlinfo[','.join(row).split(',|zsy|')[0]] = ''
    random.shuffle(dicturl)
    print(len(dicturl))

    dicturlcontent = {}
    file1 = open('../../../../Classification procedure/Get relevant URLs/initial/LGallcontent.csv','r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    for row in csv_reader1:

        urlpre = ','.join(row).split(',|zhuangshuying|')[0]

        try:
            urlnew = ','.join(row).split(',|zhuangshuying|')[1]
        except IndexError as e:
            continue
        if (urlpre not in dicturlinfo):
            continue
        dicturlcontent[urlpre] = urlnew

    from selenium import webdriver
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')

    driver = webdriver.Chrome(chrome_options=chrome_options)

    driver.set_page_load_timeout(150)
    driver.set_script_timeout(150)
    f1 = open('ping_bsresulls_' + str(i) + '.csv', 'a')
    f2 = open('ping_bserrors_' + str(i) + '.csv', 'a')

    for num in range(0, len(dicturl)):
        time1 = ''
        cmd = dicturl[num]
        cmdlist = cmd.split(',|zsy|')

        if (cmdlist[0] in dicturlcontent):
            print(cmdlist)
            try:
                url = dicturlcontent[cmdlist[0]]
                time1 = str(datetime.datetime.now())
                driver.get(url)
                form = driver.find_elements_by_tag_name('form')[int(cmdlist[1])]
                for m in range(2, len(cmdlist)):
                    if (cmdlist[m] != ' '):
                        id = cmdlist[m].split('=')[0]
                        type = cmdlist[m].split('=')[1]
                        value = cmdlist[m].split('=')[2]
                        print(id)
                        print(type)
                        print(value)
                        if (type == 'radio'):
                            elem = driver.find_elements_by_id(id)
                            for i in elem:
                                if i.get_attribute('value') == value:
                                    if (not i.is_selected()):
                                        i.click()
                                        time.sleep(10)
                                    break
                        elif (type == 'checkbox'):
                            elem = driver.find_elements_by_id(id)
                            for i in elem:
                                if i.get_attribute('value') == value:
                                    if (not i.is_selected()):
                                        i.click()
                                        time.sleep(10)
                                    break
                                else:
                                    if (i.is_selected()):
                                        i.click()

                        elif (type == 'select'):
                            selector = Select(driver.find_element_by_id(id))
                            selector.select_by_value(value)  # 通过value属性值进行选择

                        elif(type=='text'):
                            ##清空默认的值
                            elem = driver.find_element_by_id(id)
                            elem.clear()
                            elem.send_keys(value)
                            # # ##radio

                form.submit()
                time.sleep(5)
                brr = str(driver.page_source.replace('\n', ' ').replace('\t', ' '))
                print(brr)
                time2 = str(datetime.datetime.now())
                f1.writelines(',|zsy|'.join(
                    cmdlist) + ',|zsy1|' + time1 + ',|zsy1|' + time2 + ',|zhuangshuying|' + brr + '\n')
                f1.flush()


            except Exception as e:
                time2 = str(datetime.datetime.now())
                f2.writelines(',|zsy|'.join(cmdlist) + ',|zsy1|' + time1 + ',|zsy1|' + time2 + ',|zhuangshuying|' + str(
                    e).replace('\n', ' ').replace('\t', ' ') + '\n')
                f2.flush()
                continue
    driver.quit()


if __name__ == '__main__':
    #with interface information, we run ./\_init\_.py to translate ping measurement requests into the action of filling in the input fields of the corresponding form element with specific values
    pingmeasurement('../matchtemplate/RelevantLGtemplate.json','../matchkeyword/Relevantkeywordmatch.json','pingcmd.csv')
    pingmeasurement('../matchtemplate/seedLGtemplate.json','../matchkeyword/seedkeyordmatch.json','pingseedcmd.csv')
    pingmeasurementbs('../matchkeyword/Relevantkeywordmatchbs.json', 'pingcmdbs.csv')
    pingmeasurementbs('../matchkeyword/seedkeywormatch.json','pingseedcmdbs.csv')

     #Then, we automatically issue ping measurement requests (three times) to ask each VP to ping a controlled machine (IP is 112.124.15.132).
    for i in range(0,3):
        issueping(i)
    for i in range(0, 3):
        issuepingbs(i)