
import json
import csv
import re
import mechanize


# extract form elements of each LG seed URL and relevant URL
def extractformelement(url,htmlfile,output):
    brwsr = mechanize.Browser()
    dictinputseed={}
    file1 = open(url, 'r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    for row in csv_reader1:
        dictinputseed[','.join(row)]=''


    dicturl={}
    numseed=0
    num301=0
    file1 = open(htmlfile, 'r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    for row in csv_reader1:
        url=','.join(row).split(',|zhuangshuying|')[0]
        if(url not in dictinputseed):
            print('error')
            continue
        numseed+=1
        try:
            html=','.join(row).split(',|zhuangshuying|')[2]
            brwsr.set_html(html,url=url)
        except IndexError as e:
            continue
        if(html.replace(' ','')==''):
            continue
        if('301 moved permanently' in html.lower() or '302 found' in html.lower() or 'redirected' in html.lower()
        ):
            num301+=1
            continue
        try:
            dicturl[url]={}
            formcount = 0
            for form in brwsr.forms():
                dicturl[url][formcount]={}
                brwsr.select_form(nr=formcount)
                for control in form.controls:
                    try:
                        dicturl[url][formcount][control.name]=[control.type,control.possible_items()]
                    except AttributeError as e:
                        dicturl[url][formcount][control.name]=[control.type,[]]


                formcount = formcount + 1

        except mechanize._mechanize.FormNotFoundError as e:
            continue
        except AttributeError as e:
            continue
        except UnicodeDecodeError as e:
            continue
        except UnicodeEncodeError as e:
            continue

    with open(output, "w") as f:
        json.dump(dicturl, f)


## we retrieve input interface information about VPs from LG seed URLs and relevant URLs by matching their form element information with templates.
def templatematch(URL,element,output):
    keylist = {}
    file1 = open(URL, 'r')
    csv_reader1 = csv.reader(file1)
    for row in csv_reader1:
        if (','.join(row) not in keylist):
            keylist[','.join(row)] = ''




    f = open(element,
             encoding='utf-8')
    res = f.read()
    from collections import OrderedDict
    data = json.loads(res, object_pairs_hook=OrderedDict)

    # templates
    model1=["host-text", "cmd-select", "submit-submitbutton"]
    model2=["null-select", "network-select","type-submitbutton"]
    model3=["command-radio","protocol-select", "query-text", "router-select", "null-reset"]
    model4=["routers-select",  "query-select", "parameter-text", "null-resetbutton", "dontlook-text"]
    model6=["router-select", "query-radio", "arg-text", "null-submit" ]
    model7=["query-radio", "protocol-select", "addr-text","router-select", "null-reset"]
    model7_1=["query-radio",  "protocol-hidden", "addr-text", "router-select","null-reset"]
    model7_2=["query-radio",  "addr-text", "router-select","null-reset"]
    model8=["server-select", "action-select",  "args-text","null-submit"]
    model9=["cmd-select", "req-text", "null-submit"]
    dicttext={}
    dictlist={}
    for key in data:
        if key not in keylist:
            continue
        for formnum in data[key]:
            list1=[]
            for controlname in data[key][formnum]:
                controltype = data[key][formnum][controlname][0]
                str1=str(controlname+'-'+controltype)
                list1.append(str(str1))
                # possibleitem = data[key][formnum][controlname][1]
            list1.sort(reverse=True)
            if(','.join(list1) not in dictlist):
                dictlist[','.join(list1)]=1
            else:
                dictlist[','.join(list1)]+=1

            # print(list1)
            if(list1==[]):
                continue
            if set(list1) == set(model1) :
                dicttext[key]={'Template':1, formnum:data[key][formnum]}
            elif(set(list1) == set(model2) ):
                dicttext[key]={'Template':2,formnum:data[key][formnum]}
            elif(set(list1) == set(model3)):
                dicttext[key] = {'Template': 3, formnum: data[key][formnum]}
            elif (set(list1) == set(model4) ):
                dicttext[key] = {'Template': 4, formnum: data[key][formnum]}
            elif (set(list1) == set(model6) ):
                dicttext[key] = {'Template': 6, formnum: data[key][formnum]}
            elif(set(list1) == set(model7) or set(list1) == set(model7_1) or set(list1) == set(model7_2)):
                dicttext[key] = {'Template': 7, formnum: data[key][formnum]}
            elif(set(list1) == set(model8)):
                dicttext[key] = {'Template': 8, formnum: data[key][formnum]}
            elif (set(list1) == set(model9)):
                dicttext[key] = {'Template': 9, formnum: data[key][formnum]}

    print(len(dicttext))
    with open(output, "w") as f:
        json.dump(dicttext, f)
    d_order = sorted(dictlist.items(), key=lambda x: x[1], reverse=False)
    print(d_order)



#keyword-matching
def templatebird(URL,content,output):

    keylist = {}
    file1 = open(URL, 'r')
    csv_reader1 = csv.reader(file1)
    for row in csv_reader1:
        if (','.join(row) not in keylist):
            keylist[','.join(row)] = ''
    ##得到每个LG网页对应form
    birdxpath={}

    file1 = open(content, 'r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    for row in csv_reader1:
        url = ','.join(row).split(',|zhuangshuying|')[0]
        if (url not in keylist):
            continue

        try:
            html = ','.join(row).split(',|zhuangshuying|')[2]
        except IndexError as e:
            continue
        if (html.replace(' ', '') == ''):
            continue

        if ('Bird' in html and 'API' in html and 'Router ID' in html and 'Last Reconfigure' in html):
            ##node <li class="hosts"><a id="lg" href="#">all</a></li>
            print(url)
            ipad1 = re.findall(r'Router ID: (.*?)\&nbsp', html, re.S | re.M)

            if (ipad1):
                ipad = re.findall(r"\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b", ipad1[0])
                if (ipad):
                    print(ipad[0])
                    birdxpath[url] = ipad[0]

    with open(output, "w") as f:
        json.dump(birdxpath, f)



if __name__ == '__main__':
    # extract form elements of each LG seed URL
    extractformelement('../../../../LG seed set/All-LGseedpages/inputseed.csv','../../../../LG seed set/All-LGseedpages/urlcontentnew.csv','seedLGleafXpath.json')
    # extract form elements of each relevant uRL
    extractformelement('../../../../Classification procedure/Get relevant URLs/initial/relevanceLG.csv','../../../../Classification procedure/Get relevant URLs/initial/LGallcontent.csv','RelevantLGleafXpath.json')


    # we retrieve input interface information about VPs from LG seed URLs and relevant URLs by matching their form element information with templates.
    templatematch('../../../../LG seed set/All-LGseedpages/afterManualCheck/isLG.csv','seedLGleafXpath.json','seedLGtemplate.json')
    templatematch('../../../../Classification procedure/Get relevant URLs/initial/relevanceLG.csv','RelevantLGleafXpath.json','RelevantLGtemplate.json')


    ##match bird template
    templatebird('../../../../LG seed set/All-LGseedpages/afterManualCheck/isLG.csv','../../../../LG seed set/All-LGseedpages/urlcontentnew.csv','seedLGbird.json')
    templatebird('../../../../Classification procedure/Get relevant URLs/initial/relevanceLG.csv','../../../../Classification procedure/Get relevant URLs/initial/LGallcontent.csv','RelevantLGbird.json')

