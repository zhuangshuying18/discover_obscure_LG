import csv
import json

from bs4 import BeautifulSoup
from sklearn.metrics import classification_report as clsr, accuracy_score,recall_score

import joblib
from sklearn.feature_extraction.text import CountVectorizer
import matplotlib
#matplotlib.use("Agg")
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import precision_recall_curve, average_precision_score


# retrieve input interface information about VPs from LG seed URLs and relevant URLs by matching their form element information with specific keywords.
def keywordmatch(templatefile,birdfile,URL,formelement,output):
    template={}
    f = open(templatefile,encoding='utf-8')
    res = f.read()
    from collections import OrderedDict
    data = json.loads(res, object_pairs_hook=OrderedDict)
    for key in data:
        template[key]=''

    f = open(birdfile, encoding='utf-8')
    res = f.read()
    from collections import OrderedDict
    data = json.loads(res, object_pairs_hook=OrderedDict)
    for key in data:
        template[key]=''



    contenturl = {}
    file = open(URL, 'r')
    csv_reader1 = csv.reader(file)
    for row in csv_reader1:
        if(','.join(row) not in template):
            contenturl[','.join(row)] = 0
    print(len(contenturl))


    dictkeyword={}
    f = open(formelement, encoding='utf-8')
    res = f.read()
    from collections import OrderedDict
    data = json.loads(res, object_pairs_hook=OrderedDict)
    for key in data:
        if(key in contenturl):
            for formnum in data[key]:
                for controlname in data[key][formnum]:
                    str1=[]
                    # print(data[key][formnum][controlname][1])
                    for key2 in data[key][formnum][controlname][1]:
                        str1.append(key2.lower())
                    if ('ping' in str1 or 'bgp' in str1 or 'trace' in str1):
                        dictkeyword[key] = {str(formnum): data[key][formnum]}
                        break

    with open(output, "w") as f:
        json.dump(dictkeyword, f)
    print(len(dictkeyword))


##In additional to mechanize, we also use  BeautifulSoup to extract form elements of each LG seed URL and relevant URL
def extract(URL,content,output):
    contenturl = {}
    file = open(URL, 'r')
    csv_reader1 = csv.reader(file)
    for row in csv_reader1:
        contenturl[','.join(row)] = {}
    print(len(contenturl))
    file1 = open(content, 'r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    for row in csv_reader1:
        url = ','.join(row).split(',|zhuangshuying|')[0]
        if (url[:4] != 'http'):
            continue
        if (url not in contenturl):
            continue
        try:
            html = ','.join(row).split(',|zhuangshuying|')[2]
        except IndexError as e:
            continue
        if (html.replace(' ', '') == ''):
            continue
        html_proc = BeautifulSoup(html)
        forms = html_proc.findAll('form')
        if (not forms):
            continue
        for i in range(0, len(forms)):
            contenturl[url][i] = []

            form = forms[i]
            html_proc1 = BeautifulSoup(str(form))
            select = html_proc1.select('select')
            #select
            if (select):
                for selecti in select:
                    name = selecti.get('name')
                    type = 'select'
                    id = selecti.get('id')
                    onclick = selecti.get('onclick')
                    placeholder = selecti.get('placeholder')
                    lselect = ['', '', '', '', '', [], []]
                    if (onclick):
                        lselect[3] = onclick
                    if (placeholder):
                        lselect[4] = placeholder
                    if (name):
                        lselect[0] = name
                    if (id):
                        lselect[1] = id
                    lselect[2] = type

                    html_proc2 = BeautifulSoup(str(selecti))
                    option = html_proc2.findAll('option')
                    if (option):
                        for k in option:
                            value = k.get('value')
                            text = k.get_text()
                            if (value):
                                lselect[6].append(value)
                                if (text):
                                    lselect[5].append(text)
                                else:
                                    lselect[5].append('')

                    contenturl[url][i].append(lselect)

            ##button
            for li in ['input', 'button']:
                button = html_proc1.findAll(li)
                if (button):
                    for buttoni in button:
                        id = buttoni.get('id')
                        name = buttoni.get('name')
                        onclick = buttoni.get('onclick')
                        type = buttoni.get('type')
                        text = buttoni.get_text()
                        placeholder = buttoni.get('placeholder')
                        lbutton = ['', '', '', '', '', [], []]
                        value = buttoni.get('value')
                        if (onclick):
                            lbutton[3] = onclick
                        if (placeholder):
                            lbutton[4] = placeholder
                        if (name):
                            lbutton[0] = name
                        if (id):
                            lbutton[1] = id
                        if (type):
                            lbutton[2] = type

                        if (type == 'radio' or type == 'checkbox'):

                            tag = 0
                            for m in range(0, len(contenturl[url][i])):
                                list1 = contenturl[url][i][m]
                                if (name == list1[0] and type == list1[1]):
                                    tag = 1
                                    if (value):
                                        contenturl[url][i][m][6].append(value)
                                        if (text):
                                            contenturl[url][i][m][5].append(text)
                                        else:
                                            contenturl[url][i][m][5].append('')
                                    break

                            if (tag == 0):
                                if (value):
                                    lbutton[6].append(value)
                                    if (text):
                                        lbutton[5].append(text)
                                    else:
                                        lbutton[5].append('')
                                contenturl[url][i].append(lbutton)


                        else:
                            if (text):
                                lbutton[5].append(text)
                            contenturl[url][i].append(lbutton)
    with open(output, "w") as f:
        json.dump(contenturl, f)



def keywordmatchnew(templatefile,keywordmatchfile,birdfile,URL, formelement,output):
    template = {}
    f = open(templatefile, encoding='utf-8')
    res = f.read()
    from collections import OrderedDict
    data = json.loads(res, object_pairs_hook=OrderedDict)
    for key in data:
        template[key] = ''

    f = open(keywordmatchfile,  encoding='utf-8')  #
    res = f.read()  #
    from collections import OrderedDict
    data = json.loads(res, object_pairs_hook=OrderedDict)
    for key in data:
        template[key] = ''

    f = open(birdfile, encoding='utf-8')  #
    res = f.read()
    from collections import OrderedDict
    data = json.loads(res, object_pairs_hook=OrderedDict)
    for key in data:
        template[key] = ''

    dicturl = {}

    file = open(URL,'r')
    csv_reader1 = csv.reader(file)
    for row in csv_reader1:
        if (','.join(row) not in template):
            dicturl[','.join(row)] = ''


    f = open(formelement,encoding='utf-8')
    res = f.read()
    from collections import OrderedDict
    data = json.loads(res, object_pairs_hook=OrderedDict)
    # 187

    dictkeyword = {}
    for key in data:
        if key not in dicturl:
            continue
        for formnum in data[key]:
            for controllist in data[key][formnum]:
                controltext = controllist[5]
                controlvalue = controllist[6]
                str1 = []
                for key2 in controltext:
                    str1.append(key2.lower())
                for key2 in controlvalue:
                    str1.append(key2.lower())
                if ('ping' in str1 or 'bgp' in str1 or 'traceroute' in str1):
                    print(key)
                    if(key not in dictkeyword):
                        dictkeyword[key]={}
                    dictkeyword[key][str(formnum)]= data[key][formnum]

    with open(output, "w") as f:
            json.dump(dictkeyword, f)
    print(len(dictkeyword))
if __name__ == '__main__':
      # retrieve input interface information about VPs from relevant URLs by matching their form element information with specific keywords.
    keywordmatch('../matchtemplate/RelevantLGtemplate.json','../matchtemplate/RelevantLGbird.json','../../../../Classification procedure/Get relevant URLs/second_iteration/relevanceLG.csv','../matchtemplate/RelevantLGleafXpath.json','Relevantkeywordmatch.json')
    #
    ####In additional to mechanize, we also use beautiful to extract form elements of each rrelevant URL
    extract('../../../../Classification procedure/Get relevant URLs/second_iteration/relevanceLG.csv','../../../../Classification procedure/Get relevant URLs/second_iteration/LGallcontent.csv','Relevantformbs.json')

    # retrieve input interface information about VPs from relevant URLs by matching their form element information with specific keywords.
    keywordmatchnew('../matchtemplate/RelevantLGtemplate.json','Relevantkeywordmatch.json','../matchtemplate/RelevantLGbird.json','../../../../Classification procedure/Get relevant URLs/second_iteration/relevanceLG.csv','Relevantformbs.json','Relevantkeywordmatchbs.json')


