import scapy
from scapy.all import *
from scapy.utils import PcapReader
import csv
import datetime
import json


import scapy
from scapy.all import *
from scapy.utils import PcapReader
import csv
import datetime
import json


def deal(seed):
    ##We have recorded the start time of sending each measurement request and the end time of receiving corresponding reply， now we extract them
    dictpre = {}
    csv.field_size_limit(500 * 1024 * 1024)
    file1 = open('ping_resulls_'+str(seed)+'.csv', 'r')
    csv_reader1 = csv.reader((line.replace('\0', '') for line in file1))
    for row in csv_reader1:
        if (',|zsy1|' in ','.join(row)):
            betime=datetime.datetime.strptime(','.join(row).split(',|zsy1|')[1],'%Y-%m-%d %H:%M:%S.%f').timestamp()
            edtime=datetime.datetime.strptime(','.join(row).split(',|zsy1|')[2].split(',|zhuangshuying|')[0],'%Y-%m-%d %H:%M:%S.%f').timestamp()

            dictpre[','.join(row).split(',|zsy1|')[0]] = [betime,edtime,'']
    file1 = open('ping_errors_'+str(seed)+'.csv', 'r')
    csv_reader1 = csv.reader((line.replace('\0', '') for line in file1))
    for row in csv_reader1:
        if (',|zsy1|' in ','.join(row)):
            betime=datetime.datetime.strptime(','.join(row).split(',|zsy1|')[1],'%Y-%m-%d %H:%M:%S.%f').timestamp()
            edtime=datetime.datetime.strptime(','.join(row).split(',|zsy1|')[2].split(',|zhuangshuying|')[0],'%Y-%m-%d %H:%M:%S.%f').timestamp()
            dictpre[','.join(row).split(',|zsy1|')[0]] =  [betime,edtime,'']


    ##Since our ping measurement requests are sent sequentially, there should be no time overlap
    dictpre=sorted(dictpre.items(), key=lambda x: x[1], reverse=False)
    latertime=[]
    begintime=[]
    for key in dictpre:
        latertime.append(key[1][1])
        begintime.append(key[1][0])
    for i in range(0,len(latertime)-1):
        if(latertime[i]>begintime[i+1]):
            print('error')

    ##we parse .cap file and record the arrival time of ICMP packets
    dictreplay={}
    packets=rdpcap("resultnew.cap")
    for data in packets:
        s = repr(data)
        # print(s)
        if('<ICMP  ' in s):
            if(data.payload.src=='185.31.172.235'):
                print(float(data.time))
            if(data.payload.src not in dictreplay):
                dictreplay[float(data.time)]=[data.payload.src,0]


    #match each VP to corresponding IP address
    dictcmdserver={}
    for key in dictpre:
        betime=key[1][0]
        edtime=key[1][1]
        for time in dictreplay:
            if(time>betime and time<edtime):
                if(dictreplay[time][0]=='223.91.34.215' or dictreplay[time][0]=='47.88.44.97' or dictreplay[time][0]=='39.99.233.63'):
                    continue
                ##表示找到了区间
                dictreplay[time][1]=1
                if(key[0] not in dictcmdserver):
                    dictcmdserver[key[0]]=[dictreplay[time][0]]
                else:
                    if(dictreplay[time][0] not in dictcmdserver[key[0]]):
                        dictcmdserver[key[0]].append(dictreplay[time][0])


    ##record automatable VPs and correspond IP addresses
    print(dictcmdserver)
    file=open('serverip'+str(seed)+'.csv','w')
    for key in dictcmdserver:
        if(len(dictcmdserver[key])==1):
            file.writelines(key+',|zhuangshuying|'+dictcmdserver[key][0]+'\n')
        else:
            print(key)
            print(dictcmdserver[key])

    print(len(dictcmdserver))
    print(len(dictpre))




def dealbs(seed):
    ##    ##We have recorded the start time of sending each measurement request and the end time of receiving corresponding reply， now we extract them
    dictpre = {}
    csv.field_size_limit(500 * 1024 * 1024)
    file1 = open('ping_bsresulls_'+str(seed)+'.csv', 'r')
    csv_reader1 = csv.reader((line.replace('\0', '') for line in file1))
    for row in csv_reader1:
        if (',|zsy1|' in ','.join(row)):
            betime=datetime.datetime.strptime(','.join(row).split(',|zsy1|')[1],'%Y-%m-%d %H:%M:%S.%f').timestamp()
            edtime=datetime.datetime.strptime(','.join(row).split(',|zsy1|')[2].split(',|zhuangshuying|')[0],'%Y-%m-%d %H:%M:%S.%f').timestamp()

            dictpre[','.join(row).split(',|zsy1|')[0]] = [betime,edtime,'']
    file1 = open('ping_bserrors_'+str(seed)+'.csv', 'r')
    csv_reader1 = csv.reader((line.replace('\0', '') for line in file1))
    for row in csv_reader1:
        if (',|zsy1|' in ','.join(row)):
            betime=datetime.datetime.strptime(','.join(row).split(',|zsy1|')[1],'%Y-%m-%d %H:%M:%S.%f').timestamp()
            edtime=datetime.datetime.strptime(','.join(row).split(',|zsy1|')[2].split(',|zhuangshuying|')[0],'%Y-%m-%d %H:%M:%S.%f').timestamp()
            dictpre[','.join(row).split(',|zsy1|')[0]] =  [betime,edtime,'']


    ##Since our ping measurement requests are sent sequentially, there should be no time overlap
    dictpre=sorted(dictpre.items(), key=lambda x: x[1], reverse=False)
    latertime=[]
    begintime=[]
    for key in dictpre:
        latertime.append(key[1][1])
        begintime.append(key[1][0])
    for i in range(0,len(latertime)-1):
        if(latertime[i]>begintime[i+1]):
            print('error')


    ##we parse .cap file and record the arrival time of ICMP packets
    dictreplay={}
    packets=rdpcap("resultnew.cap")
    for data in packets:
        s = repr(data)
        if('<ICMP  ' in s):

            if(data.payload.src not in dictreplay):
                dictreplay[float(data.time)]=[data.payload.src,0]
    # print(dictreplay)
    dictcmdserver={}
    for key in dictpre:
        betime=key[1][0]
        edtime=key[1][1]
        for time in dictreplay:
            if(time>betime and time<edtime):
                if (dictreplay[time][0] == '223.91.34.215' or dictreplay[time][0] == '47.88.44.97' or dictreplay[time][
                    0] == '39.99.233.63'):
                    continue
                dictreplay[time][1]=1
                if(key[0] not in dictcmdserver):
                    dictcmdserver[key[0]]=[dictreplay[time][0]]
                else:
                    if(dictreplay[time][0] not in dictcmdserver[key[0]]):
                        dictcmdserver[key[0]].append(dictreplay[time][0])



    ##record automatable VPs and correspond IP addresses
    print(dictcmdserver)
    file=open('bsserverip'+str(seed)+'.csv','w')
    for key in dictcmdserver:
        if(len(dictcmdserver[key])==1):
            file.writelines(key+',|zhuangshuying|'+dictcmdserver[key][0]+'\n')
        else:
            print(key)
            print(dictcmdserver[key])

    print(len(dictcmdserver))
    print(len(dictpre))




def recordinfoaboutVP(pingfile,templatefile, keywordfile, birdfile, pingbsfile, bsfile,output):
    dictattribute = {}
    dictLGnum = {}
    file1 = open(pingfile, 'r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    for row in csv_reader1:
        url = ','.join(row).split(',|zsy|')[0]
        dictLGnum[url] = ''

    ##In order to ensure the reliability of the results，we only record the VP that are corresponding to only one IP
    dictcmd = {}
    for i in range(0, 3):
        file1 = open('serverip' + str(i) + '.csv', 'r')
        csv_reader1 = csv.reader((line.replace('\0', '') for line in file1))
        for row in csv_reader1:
            url = ','.join(row).split(',|zsy|')[0]
            if (url not in dictLGnum):
                continue
            ip = ','.join(row).split(',|zhuangshuying|')[1]
            cmd = ','.join(row).split(',|zhuangshuying|')[0]
            if (cmd not in dictcmd):
                dictcmd[cmd] = [ip]
            elif (ip not in dictcmd[cmd]):
                dictcmd[cmd].append(ip)

    num = 0
    for key in dictcmd:
        ##In order to ensure the reliability of the results，we only record the VP that are corresponding to only one IP

        if (len(dictcmd[key]) == 1):
            num += 1
            url = key.split(',|zsy|')[0]
            if (key.split(',|zsy|')[4] == ' '):
                vp = 'form' + str(key.split(',|zsy|')[1])
            else:
                vp = key.split(',|zsy|')[4].split('=')[2]
            if (url not in dictattribute and url + '/' not in dictattribute and url.split('/')[0] not in dictattribute):
                dictattribute[url] = {}
                dictattribute[url]['VP'] = {}
            if (url in dictattribute):
                str1 = key.split(',|zsy|')[2] + ';' + key.split(',|zsy|')[3] + ';' + key.split(',|zsy|')[4]
                dictattribute[url]['VP'][vp] = [dictcmd[key][0], '', '', '', '', '', str1]
            elif (url + '/' in dictattribute):
                str1 = key.split(',|zsy|')[2] + ';' + key.split(',|zsy|')[3] + ';' + key.split(',|zsy|')[4]
                dictattribute[url + '/']['VP'][vp] = [dictcmd[key][0], '', '', '', '', '', str1]
            elif (url.split('/')[0] in dictattribute):
                str1 = key.split(',|zsy|')[2] + ';' + key.split(',|zsy|')[3] + ';' + key.split(',|zsy|')[4]
                dictattribute[url.split('/')[0]]['VP'][vp] = [dictcmd[key][0], '', '', '', '', '', str1]
                

    f = open(templatefile,
             encoding='utf-8')
    res = f.read()  #
    from collections import OrderedDict
    data = json.loads(res, object_pairs_hook=OrderedDict)
    for key in data:
        tem = data[key]['Template']
        for form in data[key]:
            if (form != 'Template'):
                liststr = data[key][form]
                if (key in dictattribute):
                    dictattribute[key]['Commands']=[]
                else:
                    continue
                if (tem == 1):
                    dictattribute[key]['Commands'] = (liststr['cmd'][1])
                elif (tem == 2):
                    dictattribute[key]['Commands'] = (liststr['null'][1])
                elif (tem == 3):
                    dictattribute[key]['Commands'] = (liststr['command'][1])
                elif (tem == 4):
                    dictattribute[key]['Commands'] = (liststr['query'][1])
                elif (tem == 6):
                    dictattribute[key]['Commands'] = (liststr['query'][1])
                elif (tem == 7):
                    dictattribute[key]['Commands'] = (liststr['query'][1])
                elif (tem == 8):
                    dictattribute[key]['Commands'] = (liststr['action'][1])
                elif (tem == 9):
                    dictattribute[key]['Commands'] = (liststr['cmd'][1])

    f = open(keywordfile,
             encoding='utf-8')
    res = f.read()  # 读文件
    from collections import OrderedDict
    data = json.loads(res, object_pairs_hook=OrderedDict)
    for key in data:
        if (key in dictattribute):
            dictattribute[key]['Commands'] = []
        else:
            continue

        for formnum in data[key]:
            for controlname in data[key][formnum]:
                str1 = []
                for key2 in data[key][formnum][controlname][1]:
                    str1.append(key2.lower())
                if ('ping' in str1 or 'bgp' in str1 or 'trace' in str1):
                    dictattribute[key]['Commands'] = data[key][formnum][controlname][1]


    f = open( birdfile,  encoding='utf-8')
    res = f.read()
    from collections import OrderedDict
    data = json.loads(res, object_pairs_hook=OrderedDict)
    for key in data:
        if (key not in dictattribute):
            dictattribute[key] = {}
            dictattribute[key]['Commands'] = ['BGP(IXP)']
            dictattribute[key]['VP'] = {}
            dictattribute[key]['VP']['ServerID'] = [data[key], '', '', '', '', '', '']


    dictLGnum1 = {}
    file1 = open( pingbsfile,  'r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    for row in csv_reader1:
        url = ','.join(row).split(',|zsy|')[0]
        dictLGnum1[url] = ''


    dictcmd1 = {}
    for i in range(0, 3):
        file1 = open(
            'bsserverip' + str( i) + '.csv', 'r')
        csv_reader1 = csv.reader((line.replace('\0', '') for line in file1))
        for row in csv_reader1:
            url = ','.join(row).split(',|zsy|')[0]
            if (url not in dictLGnum1):
                continue
            ip = ','.join(row).split(',|zhuangshuying|')[1]
            cmd = ','.join(row).split(',|zhuangshuying|')[0]
            if (cmd not in dictcmd1):
                dictcmd1[cmd] = [ip]
            elif (ip not in dictcmd1[cmd]):
                dictcmd1[cmd].append(ip)


    for key in dictcmd1:
        ##In order to ensure the reliability of the results，we only record the VP that are corresponding to only one IP
        if (len(dictcmd1[key]) == 1):
            url = key.split(',|zsy|')[0]
            if (key.split(',|zsy|')[4] == ' '):
                vp = 'form' + str(key.split(',|zsy|')[1])
            else:
                vp = key.split(',|zsy|')[4].split('=')[2]
            if (url not in dictattribute and url + '/' not in dictattribute and url.split('/')[0] not in dictattribute):
                dictattribute[url] = {}
                dictattribute[url]['VP'] = {}
            if (url in dictattribute):
                str1 = key.split(',|zsy|')[2] + ';' + key.split(',|zsy|')[3] + ';' + key.split(',|zsy|')[4]
                dictattribute[url]['VP'][vp] = [dictcmd1[key][0], '', '', '', '', '', str1]
            elif (url + '/' in dictattribute):
                str1 = key.split(',|zsy|')[2] + ';' + key.split(',|zsy|')[3] + ';' + key.split(',|zsy|')[4]
                dictattribute[url + '/']['VP'][vp] = [dictcmd1[key][0], '', '', '', '', '', str1]
            elif (url.split('/')[0] in dictattribute):
                str1 = key.split(',|zsy|')[2] + ';' + key.split(',|zsy|')[3] + ';' + key.split(',|zsy|')[4]
                dictattribute[url.split('/')[0]]['VP'][vp] = [dictcmd1[key][0], '', '', '', '', '', str1]

    f = open(bsfile,
             encoding='utf-8')
    res = f.read()
    from collections import OrderedDict
    data = json.loads(res, object_pairs_hook=OrderedDict)
    for key in data:
        if (key in dictattribute):
            dictattribute[key]['Commands'] = []
        else:
            continue
        for formnum in data[key]:
            list1 = []
            tag = 0
            for controllist in data[key][formnum]:
                controlvalue = controllist[6]
                controltext = controllist[5]
                controltype = controllist[2]
                str1 = []
                for key2 in controlvalue:
                    str1.append(key2.lower())
                if ('ping' in str1 or 'bgp' in str1 or 'traceroute' in str1):
                    dictattribute[key]['Commands'] = controlvalue
                    tag = 1
                if ('LookingGlass' in controllist[4] and controltype == 'button'):
                    list1.append(controltext[0])

            if (tag == 0):
                dictattribute[key]['Commands'] = list1

    with open(output, "w") as f:
        json.dump(dictattribute, f)
    print("the number of LG servers")
    print(len(dictattribute))
    num = 0
    dictvp = {}
    for key in dictattribute:
        for key1 in dictattribute[key]['VP']:
            num += 1
            dictvp[dictattribute[key]['VP'][key1][0]] = ''

    print('the number of VPs')
    print(num)
    print('the number of unique VPs')
    print(len(dictvp))




if __name__ == '__main__':
    #we parse ICMP packets and determine automatable VPs with their IP addresses
    # for i in range(0, 3):
    #     deal(i)
    # for i in range(0,3):
    #     dealbs(i)

    #information about the automatable VPs are recorded in files
    recordinfoaboutVP('pingcmd.csv','../matchtemplate/RelevantLGtemplate.json','../matchkeyword/Relevantkeywordmatch.json','../matchtemplate/RelevantLGbird.json','pingcmdbs.csv','../matchkeyword/Relevantkeywordmatchbs.json',"Relevant3LGlist.json")
