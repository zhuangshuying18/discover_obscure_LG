
import urllib.request
import ssl
import re
import csv
import json

from IPy import IP
from bs4 import BeautifulSoup as bs
from geopy.distance import geodesic
import json
import json
import csv
import json
import csv
import matplotlib.pyplot as plt
# from mpl_toolkits.basemap import Basemap
from IPy import IP
from IPy import IP

import numpy as np
import matplotlib
from pandas import np
###first, we query db9 for the geo information
def getallIPlist():
    filelist = [
        "../../../Automatable_tool/initial/request_response/seedLGlist.json",
        '../../../Automatable_tool/initial/request_response/RelevantLGlist.json',
        '../../../Automatable_tool/second_iteration/request_response/Relevant2LGlist.json',
        '../../../Automatable_tool/third_iteration/request_response/Relevant3LGlist.json',
        '../../../Automatable_tool/forth_iteration/request_response/Relevant4LGlist.json']
    dictip={}
    file=open('alliplist.csv','w')
    for ff in filelist:
        with open(ff, 'r') as load_f:
            load_dict = json.load(load_f)
        for key in load_dict:
            for key1 in load_dict[key]['VP']:
                dictip[load_dict[key]['VP'][key1][0]]=''
    for key in dictip:
        file.writelines(key+'\n')

def querydb9():
    dictgeo = []
    file1 = open('DB9-IP-COUNTRY-REGION-CITY-LATITUDE-LONGITUDE-ZIPCODE.CSV/IP-COUNTRY-REGION-CITY-LATITUDE-LONGITUDE-ZIPCODE.CSV','r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    for row in csv_reader1:
        dictgeo.append(row)

    dictip = {}
    file1 = open('alliplist.csv', 'r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    for row in csv_reader1:
        ip1 = ','.join(row)
        ip = IP(ip1)
        print(ip1 + ',' + str(ip.int()))
        dictip[ip1] = [ip.int(), []]

    dictnew = sorted(dictip.items(), key=lambda d: d[1], reverse=False)

    jbe = 0
    for i in range(0, len(dictgeo)):
        for j in range(jbe, len(dictnew)):
            if (int(dictnew[j][1][0]) >= int(dictgeo[i][0]) and int(dictnew[j][1][0]) <= int(dictgeo[i][1])):
                dictip[dictnew[j][0]][1] = dictgeo[i]
            if (int(dictnew[j][1][0]) > int(dictgeo[i][1])):
                jbe = j
                break

    file = open('ipserverlocation.csv', 'w')
    for key in dictip:
        file.writelines(key + ',|zsy|' + str(dictip[key][0]) + ',|zsy|' + ',|zsy|'.join(dictip[key][1]) + '\n')

##use the geoinformation and ASN info to update information about each automatable VP
def updateinformation():
    filelist = [
        "../../../Automatable_tool/initial/request_response/seedLGlist.json",
        '../../../Automatable_tool/initial/request_response/RelevantLGlist.json',
        '../../../Automatable_tool/second_iteration/request_response/Relevant2LGlist.json',
        '../../../Automatable_tool/third_iteration/request_response/Relevant3LGlist.json',
        '../../../Automatable_tool/forth_iteration/request_response/Relevant4LGlist.json']

    for fi in filelist:
        f = open(fi, encoding='utf-8')
        res = f.read()
        from collections import OrderedDict
        data = json.loads(res, object_pairs_hook=OrderedDict)

        dictipinfo = {}
        file1 = open('ipserverlocation.csv', 'r')
        csv_reader1 = csv.reader(file1)
        csv.field_size_limit(500 * 1024 * 1024)
        for row in csv_reader1:
            country = ','.join(row).split(',|zsy|')[5]
            city = ','.join(row).split(',|zsy|')[7]
            lan = float(','.join(row).split(',|zsy|')[8])
            lon = float(','.join(row).split(',|zsy|')[9])
            ip = ','.join(row).split(',|zsy|')[0]
            dictipinfo[ip] = [country, city, str(lan), str(lon)]

        dictas = {}
        dictasnum = {}
        file1 = open(
            '../VP2AS/prefixmatching/ipASN.csv',
            'r')
        csv_reader1 = csv.reader(file1)
        csv.field_size_limit(500 * 1024 * 1024)
        for row in csv_reader1:
            ip = ','.join(row).split(',|zsy|')[0]
            dictas[ip] = ','.join(row).split(',|zsy|')[1]

        for key in data:
            for key1 in data[key]['VP']:
                if (data[key]['VP'][key1][0] in dictipinfo):
                    data[key]['VP'][key1][2] = dictipinfo[data[key]['VP'][key1][0]][0]
                    data[key]['VP'][key1][3] = dictipinfo[data[key]['VP'][key1][0]][1]
                    data[key]['VP'][key1][4] = dictipinfo[data[key]['VP'][key1][0]][2]
                    data[key]['VP'][key1][5] = dictipinfo[data[key]['VP'][key1][0]][3]
                if (data[key]['VP'][key1][0] in dictas):
                    data[key]['VP'][key1][1] = dictas[data[key]['VP'][key1][0]]
                    dictasnum[dictas[data[key]['VP'][key1][0]]] = ''
        with open(fi.split('request_response/')[1].split('.json')[0]+"update.json", "w") as f:
            json.dump(data, f)




#We find the country and city level locations of VPs from pages that match the template of Telephone LG project [11] have been explicitly given in html files.
#We try to use this reliable geographic information
def obtainVPgeo():
    ##template1
    dicturl={}
    filelist = ["../../../Automatable_tool/initial/matchtemplate/seedLGtemplate.json",
                '../../../Automatable_tool/initial/matchtemplate/RelevantLGtemplate.json',
                '../../../Automatable_tool/second_iteration/matchtemplate/RelevantLGtemplate.json',
                '../../../Automatable_tool/third_iteration/matchtemplate/RelevantLGtemplate.json',
                '../../../Automatable_tool/forth_iteration/matchtemplate/RelevantLGtemplate.json']
    filecontent = ["../../../../Classification procedure/Get relevant URLs/initial/LGallcontent.csv",
                   '../../../../Classification procedure/Get relevant URLs/second_iteration/LGallcontent.csv',
                   '../../../../Classification procedure/Get relevant URLs/third_iteration/LGallcontent.csv',
                '../../../../Classification procedure/Get relevant URLs/forth_iteration/LGallcontent.csv']

    for ff in filelist:
        with open(ff, 'r') as load_f:
            load_dict = json.load(load_f)
        for key in load_dict:
            if(load_dict[key]["Template"]==1):
                dicturl[key]=['','']

    for ff in filecontent:
        file1 = open(ff, 'r')
        csv_reader1 = csv.reader(file1)
        csv.field_size_limit(500 * 1024 * 1024)
        for row in csv_reader1:
            try:
                html = ','.join(row).split(',|zhuangshuying|')[2]
            except IndexError as e:
                continue
            url = ','.join(row).split(',|zhuangshuying|')[0]
            if (url in dicturl):
                # print(re.findall(r'server location:(.*?)</p>', str(html.lower())))
                serverlocation=[re.findall(r'server location:(.*?)</p>', html.lower(),re.S | re.M),
                                re.findall(r'server location:(.*?)</div>', html.lower(), re.S | re.M),
                                re.findall(r'server location:(.*?)</b>', html, re.S | re.M),
                                re.findall(r'\(server location\):(.*?)</b>', html.lower(), re.S | re.M),
                                re.findall(r'服务器地点 \(Server Location\):(.*?)</b>',html, re.S | re.M),
                                re.findall(r'Datacenter Location:(.*?)</b>',html, re.S | re.M),
                                re.findall(r'服务器位置(.*?)</b>', html, re.S | re.M),
                                re.findall(r'Lokalizacja serwera:(.*?)</p>',html, re.S | re.M),


                                ]
                IPv4=[re.findall(r'ipv4:(.*?)</p>', html.lower(), re.S | re.M),
                      re.findall(r'test ipv4:(.*?)</li>', html.lower(), re.S | re.M),
                      re.findall(r'ipv4 address:(.*?)</p>', html.lower(), re.S | re.M)
                , re.findall(r'Тестовый интерфейс IPv4:(.*?)</p>', html, re.S | re.M),
                      re.findall(r'test ipv4:(.*?)</div>', html.lower(), re.S | re.M),
             re.findall(r'server ipv4:(.*?)</p>', html.lower(), re.S | re.M)
                ,re.findall(r'ipv4 de testes:(.*?)</p>', html.lower(), re.S | re.M),
                      re.findall(r'\(test ipv4\):(.*?)</p>', html.lower(), re.S | re.M),
                      re.findall(r'IPv4 \(Test IPv4\):(.*?)</p>', html, re.S | re.M),
                      re.findall(r'IPv4:(.*?)</p>',html, re.S | re.M),
                      re.findall(r'test ipv4(.*?)<br />',html.lower(), re.S | re.M),
                      re.findall(r'adres ipv4 serwera testowego:(.*?)</p>',html.lower(), re.S | re.M),
                      re.findall(r'RS2\(new\)(.*?)</font>',html, re.S | re.M),
                      re.findall(r'test ipv4:(.*?)<br>',html.lower(),re.S | re.M),
                      re.findall(r'server address:(.*?)</span>',html.lower(),re.S | re.M),
                      re.findall(r'ipv4:(.*?)</tr>',html.lower(),re.S | re.M),
                      re.findall(r'测试 IPv4(.*?)</p>',html, re.S | re.M), re.findall(r'IP IPv4 de Testes:(.*?)</p>',html, re.S | re.M)
                ]

                for serv in serverlocation:
                    if (serv):
                        if(serv[0] in  dicturl[url][1] or  dicturl[url][1]=='' ):
                            dicturl[url][1] = serv[0]


                for ipv in IPv4:
                    if(ipv):
                        ipad = re.findall(r"(?:[0-9]{1,3}\.){3}[0-9]{1,3}", ipv[0])
                        if (ipad):
                            dicturl[url][0] = ipad[0]


                if (dicturl[url][0] == '' or dicturl[url][1] == ''):
                    print(url)
    with open("template1geo.json","w") as f:
        json.dump(dicturl,f)



def transform():
    #transform the above geolocation information into standard country names and city names
    with open('template1geo.json', 'r') as load_f:
        load_dict1 = json.load(load_f)
    filelist = [ "seedLGlistupdate.json",
                'RelevantLGlistupdate.json',
                'Relevant2LGlistupdate.json',
                'Relevant3LGlistupdate.json',
                'Relevant4LGlistupdate.json']
    dictip2geo = {}
    for ff in filelist:
        with open(ff, 'r') as load_f:
            load_dict = json.load(load_f)
        for key in load_dict:
            if (key in load_dict1):
                for key1 in load_dict[key]['VP']:
                    if (load_dict[key]['VP'][key1][0] == load_dict1[key][0] and load_dict[key]['VP'][key1][3]!='-' ):
                        dictip2geo[load_dict1[key][0]] = [load_dict[key]['VP'][key1][2], load_dict[key]['VP'][key1][3]]



    dictcountry={}
    dictcountry1={}
    dictcountry2={}
    dictcountry4={}
    dictcity = {}
    file1=open('DB9-IP-COUNTRY-REGION-CITY-LATITUDE-LONGITUDE-ZIPCODE.CSV/IP2LOCATION-COUNTRY.CSV','r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    i=0
    for row in csv_reader1:
        i+=1
        if(i==1):
            continue
        dictcountry[row[0].lower()]=row[0]
        dictcountry1[row[1].lower()] = row[0]
        dictcountry2[row[2].lower()] = row[0]
        dictcountry4[row[0].lower()]=[row[0],row[1],row[2]]

    print(dictcountry2)
    listnameredu={}
    listcountry={}
    listcountry1={}
    listcountry2={}
    listcountry4={}
    file1 = open('DB9-IP-COUNTRY-REGION-CITY-LATITUDE-LONGITUDE-ZIPCODE.CSV/IP-COUNTRY-REGION-CITY-LATITUDE-LONGITUDE-ZIPCODE.CSV', 'r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    for row in csv_reader1:
        if (row[5].lower() in dictcountry and row[5]!=row[3] ):
            listcountry[row[5].lower()]=''
            continue
        if (row[5].lower() in dictcountry1 and row[5]!=row[3]):
            listcountry1[row[5].lower()] = ''
            continue
        if (row[5].lower() in dictcountry2 and row[5]!=row[3]):
            listcountry2[row[5].lower()] = ''
            continue
        if (row[5].lower() in dictcountry4 and row[5]!=row[3]):
            listcountry4[row[5].lower()] = ''
            continue

        if(row[5].lower()=='california'):
            continue
        name=row[5].lower()
        if(name in dictcity and  [row[5], row[4], row[3]]!=dictcity[name]):
            listnameredu[name]=''
        else:
            dictcity[name] = [row[5], row[4], row[3]]
        name1 = ''
        if (row[5] == 'Frankfurt am Main'):
            name1 = 'frankfurt'
        if (row[5] == 'Saint Petersburg'):
            name1 = 'saint-petersburg'
        if (row[5] == 'Hong Kong'):
            name1 = 'hongkong'

        if(name1!=''):
            if (name1 in dictcity and [row[5], row[4], row[3]] != dictcity[name1]):
                listnameredu[name1]=''
            else:
                dictcity[name1] = [row[5], row[4], row[3]]


    for key in listnameredu:
        del dictcity[key]
    del dictcity['texas']
    for key in listcountry:
        del dictcountry[key]
    for key in listcountry1:
        del dictcountry1[key]
    for key in listcountry2:
        del dictcountry2[key]
    for key in listcountry4:
        del dictcountry4[key]

    dictgeo={}

    num=0
    dictip={}
    for key in load_dict1:
        if(load_dict1[key][1]!=''):
            num+=1
            dictip[load_dict1[key][0]]=''
            geo = re.findall(r">(.*?)<", load_dict1[key][1])
            if (geo):
                geolocation=geo[0].replace('','')
            elif('<b>' in load_dict1[key][1] and '</b>' not in load_dict1[key][1]
            or ('</b>' in load_dict1[key][1] and '<b>' not in load_dict1[key][1])
            or ('</span>' in load_dict1[key][1])):
                geolocation=(load_dict1[key][1].split('>')[1].replace('',''))
            else:
                geolocation=(load_dict1[key][1])
            geolocation=geolocation.lower()
            country=''
            city=''
            if(',' in geolocation):
                list1=geolocation.split(',')
                for ilist in list1:
                    ilist=ilist.strip()
                    if(load_dict1[key][0] in dictip2geo):
                        if(ilist in dictip2geo[load_dict1[key][0]][0].lower()
                        or ilist==dictcountry4[dictip2geo[load_dict1[key][0]][0].lower()][1]
                        or ilist==dictcountry4[dictip2geo[load_dict1[key][0]][0].lower()][2]
                       ):
                            country=dictip2geo[load_dict1[key][0]][0]
                        if(ilist in dictip2geo[load_dict1[key][0]][1].lower()):
                            city=dictip2geo[load_dict1[key][0]][1]
                            country=dictip2geo[load_dict1[key][0]][0]

                if(country=='' or city==''):
                    for ilist in list1:
                        ilist = ilist.strip()
                        if (city=='' and ilist in dictcity):
                            city = dictcity[ilist][0]
                            country = dictcity[ilist][2]
                            if (ilist == 'new york'):
                                city = 'New York City'
                                country = "United States of America"
                            if (ilist == 'kong-kong'):
                                city = 'Hong Kong'
                                country = "Hong Kong"


            elif ('/' in geolocation):
                list1 = geolocation.split('/')
                for ilist in list1:
                    ilist = ilist.strip()
                    if (load_dict1[key][0] in dictip2geo):
                        if (ilist in dictip2geo[load_dict1[key][0]][0].lower()
                        or ilist==dictcountry4[dictip2geo[load_dict1[key][0]][0].lower()][1]
                        or ilist==dictcountry4[dictip2geo[load_dict1[key][0]][0].lower()][2]):
                            country = dictip2geo[load_dict1[key][0]][0]
                        if (ilist in dictip2geo[load_dict1[key][0]][1].lower()):
                            city = dictip2geo[load_dict1[key][0]][1]
                            country = dictip2geo[load_dict1[key][0]][0]

                if (country == '' or city == ''):
                    for ilist in list1:
                        ilist = ilist.strip()
                        if (city=='' and ilist in dictcity):
                            city = dictcity[ilist][0]
                            country = dictcity[ilist][2]
                            if (ilist == 'new york'):
                                city = 'New York City'
                                country = "United States of America"


            else:
                ilist = geolocation.strip()
                if (load_dict1[key][0] in dictip2geo):
                    if (ilist in dictip2geo[load_dict1[key][0]][0].lower()
                        or ilist==dictcountry4[dictip2geo[load_dict1[key][0]][0].lower()][1]
                        or ilist==dictcountry4[dictip2geo[load_dict1[key][0]][0].lower()][2]):
                        country = dictip2geo[load_dict1[key][0]][0]
                    if (ilist in dictip2geo[load_dict1[key][0]][1].lower()):
                        city = dictip2geo[load_dict1[key][0]][1]
                        country = dictip2geo[load_dict1[key][0]][0]

                if (country == '' or city == ''):
                    if (city=='' and ilist in dictcity):
                        city = dictcity[ilist][0]
                        country = dictcity[ilist][2]
                        if(ilist=='new york'):
                            city = 'New York City'
                            country = "United States of America"


            if(country!='' or city!=''):
                dictgeo[load_dict1[key][0]]=[country,city]

    dictgeo['193.180.18.23']=['Sweden','Gothenburg']
    dictgeo['93.158.205.148']=['Netherlands','Amsterdam']
    dictgeo['103.53.199.50']=["Hong Kong", "Hong Kong"]
    dictgeo['88.119.171.50']=['Netherlands','']
    dictgeo['185.25.50.85']=['Lithuania','']
    dictgeo['88.150.160.4']=['United Kingdom of Great Britain and Northern Ireland','London']
    dictgeo['88.119.175.50']=['United States of America','Chicago']
    dictgeo['109.104.118.70']=['United Kingdom of Great Britain and Northern Ireland','London']

    print(num)
    print(len(dictip))
    print(len(dictgeo))


    with open("template1geotransform.json", "w") as f:
        json.dump(dictgeo, f)

def transform1():
    #obtain latitude and longitude
    dictcountryweidu={}
    file1 = open(
        'DB9-IP-COUNTRY-REGION-CITY-LATITUDE-LONGITUDE-ZIPCODE.CSV/IP-COUNTRY-REGION-CITY-LATITUDE-LONGITUDE-ZIPCODE.CSV',
        'r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    for row in csv_reader1:
        dictcountryweidu[row[3]+'_'+row[5]]=[float(row[6]),float(row[7])]


    dicttransform1={}
    with open('template1geotransform.json', 'r') as load_f:
        load_dict2 = json.load(load_f)
    for key in load_dict2:
        str1 = load_dict2[key][0] + '_' + load_dict2[key][1]
        dicttransform1[key]=[load_dict2[key][0],load_dict2[key][1],0.0,0.0]
        if (str1 in dictcountryweidu):
            dicttransform1[key][2] = float(dictcountryweidu[str1][0])
            dicttransform1[key][3] = float(dictcountryweidu[str1][1])

    with open("template1geotransform1.json", "w") as f:
        json.dump(dicttransform1, f)


from math import radians, cos, sin, asin, sqrt

def haversine(lon1, lat1, lon2, lat2):  #
    """
    Calculate the great circle distance between two points
    on the earth (specified in decimal degrees)
    """
    lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])

    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
    c = 2 * asin(sqrt(a))
    r = 6371  #
    return c * r


def check():
    with open('template1geotransform1.json', 'r') as load_f:
        load_dict2 = json.load(load_f)
    with open('template1geo.json', 'r') as load_f:
        load_dict1 = json.load(load_f)

    filelist = ["seedLGlistupdate.json",
                'RelevantLGlistupdate.json',
                'Relevant2LGlistupdate.json',
                'Relevant3LGlistupdate.json',
                'Relevant4LGlistupdate.json']
    dictcountry={}
    dictcity={}
    for ff in filelist:
        with open(ff, 'r') as load_f:
            load_dict = json.load(load_f)
        for key in load_dict:
            if (key in load_dict1 ):
                for key1 in load_dict[key]['VP']:
                    if(load_dict[key]['VP'][key1][0]==load_dict1[key][0] and load_dict1[key][0] in load_dict2 and load_dict[key]['VP'][key1][3]!='-' ):
                        ##country
                        if(load_dict2[load_dict1[key][0]][0]!=''):
                            dictcountry[load_dict1[key][0]]=[load_dict2[load_dict1[key][0]][0], load_dict[key]['VP'][key1][2]]

                        #city
                        if(load_dict2[load_dict1[key][0]][1]!=''):
                            dictcity[load_dict1[key][0]] = [load_dict2[load_dict1[key][0]][1], load_dict[key]['VP'][key1][3],load_dict[key]['VP'][key1][2],load_dict2[load_dict1[key][0]][2],load_dict2[load_dict1[key][0]][3],float(load_dict[key]['VP'][key1][4]),float(load_dict[key]['VP'][key1][5])]
                            if (load_dict2[load_dict1[key][0]][1] != load_dict[key]['VP'][key1][3]):
                                if(load_dict2[load_dict1[key][0]][1]=='Hong Kong' and load_dict[key]['VP'][key1][2]=='Hong Kong'):
                                    m=0

    dictnewIP={}
    #we successfully retrieve the country-level locations about 390 VPs
    print(len(dictcountry))
    numcountry=0
    for key in dictcountry:
        if(dictcountry[key][0]!=dictcountry[key][1] and not (dictcountry[key][0]=='Hong Kong' and dictcountry[key][1]=='China')):
            numcountry+=1
            dictnewIP[key]=[load_dict2[key][0],load_dict2[key][1],0.0,0.0]

    print(numcountry)
    print(len(dictcity))
    numcity=0
    for key in dictcity:
        if(dictcity[key][0]!=dictcity[key][1] and not (dictcity[key][0]=='Hong Kong' and dictcity[key][2]=='Hong Kong')):

            print(dictcity[key])
            dis=haversine(dictcity[key][3],dictcity[key][4],dictcity[key][5],dictcity[key][6])
            if(dis>40):
                numcity += 1
    #we successfully retrieve the  city-level locations about 316 VPs.
    print(numcity)
    print(len(dictnewIP))
    return dictnewIP


#use reliable geoinformation to revise the information about each VP
def revise(dictnewIP):
    dictcountryweidu={}
    file1 = open(
        'DB9-IP-COUNTRY-REGION-CITY-LATITUDE-LONGITUDE-ZIPCODE.CSV/IP-COUNTRY-REGION-CITY-LATITUDE-LONGITUDE-ZIPCODE.CSV',
        'r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    for row in csv_reader1:
        dictcountryweidu[row[3]+'_'+row[5]]=[float(row[6]),float(row[7])]
    for key in dictnewIP:
        str1=dictnewIP[key][0]+'_'+dictnewIP[key][1]
        if(str1 in dictcountryweidu):
            dictnewIP[key][2]=dictcountryweidu[str1][0]
            dictnewIP[key][3]=dictcountryweidu[str1][1]

    print(dictnewIP)

    ####revise
    filelist = ["seedLGlistupdate",
                'RelevantLGlistupdate',
                'Relevant2LGlistupdate',
                'Relevant3LGlistupdate',
                'Relevant4LGlistupdate']
    for file in filelist:
        with open(file+'.json', 'r') as load_f:
            load_dict = json.load(load_f)
        for key in load_dict:
            for key1 in load_dict[key]['VP']:
                if (load_dict[key]['VP'][key1][0] in dictnewIP):
                    load_dict[key]['VP'][key1][2]=dictnewIP[load_dict[key]['VP'][key1][0]][0]
                    load_dict[key]['VP'][key1][3]=dictnewIP[load_dict[key]['VP'][key1][0]][1]
                    load_dict[key]['VP'][key1][4]=str(dictnewIP[load_dict[key]['VP'][key1][0]][2])
                    load_dict[key]['VP'][key1][5]=str(dictnewIP[load_dict[key]['VP'][key1][0]][3])



        with open(file+"revise.json", "w") as f:
            json.dump(load_dict, f)
def drawgeodistribution():
    dictseedip = {}
    with open("seedLGlistupdaterevise.json",'r') as load_f:
        load_dict = json.load(load_f)
    for key in load_dict:
        for key1 in load_dict[key]['VP']:
            try:
                dictseedip[load_dict[key]['VP'][key1][0]] = [load_dict[key]['VP'][key1][2],
                                                             load_dict[key]['VP'][key1][3],
                                                             float(load_dict[key]['VP'][key1][4]),
                                                             float(load_dict[key]['VP'][key1][5]),
                                                             load_dict[key]['VP'][key1][1]]
            except ValueError as e:
                print(load_dict[key])
    dictnewip = {}
    filelist = ['RelevantLGlistupdaterevise.json',
                'Relevant2LGlistupdaterevise.json',
                'Relevant3LGlistupdaterevise.json',
                'Relevant4LGlistupdaterevise.json']
    for ff in filelist:
        with open(ff, 'r') as load_f:
            load_dict = json.load(load_f)
        for key in load_dict:
            for key1 in load_dict[key]['VP']:
                if (load_dict[key]['VP'][key1][0] not in dictseedip):
                    dictnewip[load_dict[key]['VP'][key1][0]] = [load_dict[key]['VP'][key1][2],
                                                                load_dict[key]['VP'][key1][3],
                                                                float(load_dict[key]['VP'][key1][4]),
                                                                float(load_dict[key]['VP'][key1][5]),
                                                                load_dict[key]['VP'][key1][1]]

    print(len(dictseedip))
    print(len(dictnewip))

    dictcity={}
    dictcountry={}
    for key in dictnewip:
        city=dictnewip[key][1]
        if(city!='' and city!='-' and city not in dictcity):
            dictcity[city]=[1,dictnewip[key][2],dictnewip[key][3]]
        elif(city!='' and city!='-' and city in dictcity):
            dictcity[city][0]+=1
        countryname=dictnewip[key][0]
        if (countryname=='Macao' or countryname=='Hong Kong' or countryname=='Taiwan (Province of China)'):
            countryname='China'
        if(countryname!='' and countryname!='-' and countryname not in dictcountry):
            dictcountry[countryname] = [1]
        elif(countryname!='' and countryname!='-' and countryname  in dictcountry):
            dictcountry[countryname][0]+=1

    dictlat=[]
    dictlon=[]
    dictnum=[]
    for key in dictcity:
        dictnum.append(dictcity[key][0])
        dictlat.append(dictcity[key][1])
        dictlon.append(dictcity[key][2])


    #and 910 obscure automatable VPs cover 282 cities in 55 countries.
    print(len(dictcountry))
    print(len(dictcity))

    dictcity1 = {}
    dictcountry1 = {}

    for key in dictseedip:
        city = dictseedip[key][1]
        if (city!='' and city!='-' and city not in dictcity1):
            dictcity1[city] = [1, dictseedip[key][2],dictseedip[key][3]]
        elif(city!='' and city!='-' and city in dictcity1 ):
            dictcity1[city][0] += 1

        countryname = dictseedip[key][0]
        if (countryname=='Macao' or countryname=='Hong Kong' or countryname=='Taiwan (Province of China)'):
            countryname='China'
        if (countryname!='' and countryname!='-'  and countryname not in dictcountry1):
            dictcountry1[countryname] = [1]
        elif(countryname!='' and countryname!='-'  and countryname in dictcountry1):
            dictcountry1[countryname][0] += 1
    dictlat1 = []
    dictlon1 = []
    dictnum1 = []
    for key in dictcity1:
        dictnum1.append(dictcity1[key][0])
        dictlat1.append(dictcity1[key][1])
        dictlon1.append(dictcity1[key][2])

    # 1,446 known automatable VPs are distributed in 386 cities of 75 coun- tries
    print(len(dictcountry1))
    print(len(dictcity1))

    num=0
    numpoint=0
    for key in dictcity:
        if key not in dictcity1:
            num+=1
            numpoint+=dictcity[key][0]
    #The obscure VPs enable researchers to execute mea- surement commands from 8 new countries and 160 new cities where no known LG VPs
    print('New city')
    print(num)


    num = 0
    for key in dictcountry:
        if key not in dictcountry1:
            num += 1
            print(key)
            numpoint+=dictcountry[key][0]

    print('New country')
    print(num)


    #
    # fig, ax = plt.subplots()
    # earth = Basemap(ax=ax)
    # earth.drawcountries( linewidth=0.5)
    # earth.drawcoastlines( linewidth=0.5)
    # plt.scatter(dictlon1, dictlat1, dictnum*3 , c='blue',label='1,446 known automatable VPs',alpha=0.2, zorder=10)
    # plt.legend(loc='lower left', fontsize=10)
    # plt.scatter(dictlon, dictlat, dictnum*3 , c='red', label='910 obscure automatable VPs',alpha=0.2, zorder=10)
    # plt.legend(loc='lower left', fontsize=10)
    # plt.subplots_adjust(top=1, bottom=0, left=0, right=1, hspace=0, wspace=0)
    # plt.margins(0, 0)
    # plt.tight_layout()
    # plt.savefig('ipserverlocation.png',dpi=300)
    # plt.show()
    #


if __name__ == '__main__':
    # getallIPlist()
    # querydb9()
    # updateinformation()
    #extract locations of VPs from pages
    # obtainVPgeo()
    # transform()
    # transform1()

    # use reliable geoinformation to revise the information about each VP
    # dictnewip=check()
    # revise(dictnewip)


    #conclude that 1,446 known automatable VPs are distributed in 386 cities of 75 coun- tries, and 910 obscure automatable VPs cover 282 cities in 55 countries. The obscure VPs enable researchers to execute mea- surement commands from 8 new countries and 160 new cities where no known LG VPs have been found before.
    #draw Figure4 in our paper
    drawgeodistribution()