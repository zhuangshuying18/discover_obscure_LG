
import json
import csv
import re
import json
import json
import csv
import json
import csv
import matplotlib.pyplot as plt

import numpy as np
import matplotlib
from matplotlib.ticker import MultipleLocator
from pandas import np

# We notice some LG pages tend to explicitly give ASNs of their VPs in html  les, which we think is a reliable VP2AS mapping source
#extract AsN infomation
def extractASinfo():
    dicturl = {}
    filelist = ['../VP2Geo/seedLGlistupdaterevise.json',
               '../VP2Geo/RelevantLGlistupdaterevise.json',
                '../VP2Geo/Relevant4LGlistupdaterevise.json',
                '../VP2Geo/Relevant3LGlistupdaterevise.json',
                '..e/VP2Geo/relevant2LGlistupdaterevise.json']

    filecontent = [
        "../../../../Classification procedure/Get relevant URLs/initial/LGallcontent.csv",
        '../../../../Classification procedure/Get relevant URLs/second_iteration/LGallcontent.csv',
        '../../../../Classification procedure/Get relevant URLs/third_iteration/LGallcontent.csv',
        '../../../../Classification procedure/Get relevant URLs/forth_iteration/LGallcontent.csv']

    for ff in filelist:
        with open(ff, 'r') as load_f:
            load_dict = json.load(load_f)
        for key in load_dict:
            dicturl[key] = ['']

    dicturl1 = {}
    for ff in filecontent:
        file1 = open(ff, 'r')
        csv_reader1 = csv.reader(file1)
        csv.field_size_limit(500 * 1024 * 1024)
        for row in csv_reader1:
            try:
                html = ','.join(row).split(',|zhuangshuying|')[2]
            except IndexError as e:
                continue
            url = ','.join(row).split(',|zhuangshuying|')[0]
            if (url in dicturl):
                title = re.findall(r'<title>(.*?)<\/title>', html.lower(), re.S | re.M)
                form = re.findall(r'<form(.*?)<\/form>', html.lower(), re.S | re.M)
                listasn = []
                pattern1 = re.compile('as[0-9]+')
                pattern2 = re.compile('as [0-9]+')
                if (title):
                    as1 = pattern1.findall(title[0].lower())
                    if (as1):
                        for i in range(0, len(as1)):
                            if (as1[i] not in listasn):
                                listasn.append(as1[i])
                    as1 = pattern2.findall(title[0].lower())
                    if (as1):
                        for i in range(0, len(as1)):
                            if (as1[i] not in listasn):
                                listasn.append(as1[i])

                if (form):
                    as2 = pattern1.findall(form[0].lower())
                    if (as2):
                        for i in range(0, len(as2)):
                            if (as2[i] not in listasn):
                                listasn.append(as2[i])
                    as2 = pattern2.findall(form[0].lower())
                    if (as2):
                        for i in range(0, len(as2)):
                            if (as2[i] not in listasn):
                                listasn.append(as2[i])

                    if (listasn != [] and len(listasn) == 1):
                        dicturl1[url] = listasn
    ##extract ASinformation from pages
    with open("titleurltoAS.json", "w") as f:
        json.dump(dicturl1, f)

def obtainVP2AS():
    dicturl = {}
    with open('titleurltoAS.json', 'r') as load_f:
        load_dict = json.load(load_f)
    for key in load_dict:
        if (key == 'http://lg.as6453.net/lg/' or key == 'https://info.viatel.net/tools/lg/'):
            continue
        if (' ' in load_dict[key][0]):
            dicturl[key] = load_dict[key][0][3:]
        else:
            dicturl[key] = load_dict[key][0][2:]

    # print(dicturl)

    dictiptoAS = {}
    filelist = [
        '../VP2Geo/seedLGlistupdaterevise.json',
        '../VP2Geo/RelevantLGlistupdaterevise.json',
        '../VP2Geo/Relevant4LGlistupdaterevise.json',
        '../VP2Geo/Relevant3LGlistupdaterevise.json',
        '../VP2Geo/relevant2LGlistupdaterevise.json']
    for ff in filelist:
        with open(ff, 'r') as load_f:
            load_dict = json.load(load_f)
        for key in load_dict:
            if (key in dicturl):
                for key1 in load_dict[key]['VP']:
                    dictiptoAS[load_dict[key]['VP'][key1][0]] = dicturl[key]
                    if (load_dict[key]['VP'][key1][1] != dicturl[key]):
                        print(key)
                        print(load_dict[key]['VP'][key1][1] + ',' + dicturl[key])

    dictiptoAS['185.17.175.244'] = '60800'
    dictiptoAS['45.248.51.209'] = '134697'
    with open("ip2AStransform.json", "w") as f:
        json.dump(dictiptoAS, f)
    print(len(dictiptoAS))

def obtainbdrmapIT():
    import sqlite3
    conn = sqlite3.connect('annotations.db')

    print("Opened database successfully")
    c = conn.cursor()

    cursor = c.execute("SELECT addr, router, asn, conn_asn  from annotation")

    outfile = open('ip2as.txt', 'w')
    for row in cursor:
        for item in row:
            outfile.write(str(item) + ' ')
        outfile.write('\n')

    outfile.close()

    print("Operation done successfully")
    conn.close()


##use the  above ASN info to update information about each automatable VP
def revise():
    dictipasn = {}
    filelist = [
        '../VP2Geo/seedLGlistupdaterevise.json',
        '../VP2Geo/RelevantLGlistupdaterevise.json',
        '../VP2Geo/Relevant4LGlistupdaterevise.json',
        '../VP2Geo/Relevant3LGlistupdaterevise.json',
        '../VP2Geo/relevant2LGlistupdaterevise.json']
    for ff in filelist:
        with open(ff, 'r') as load_f:
            load_dict = json.load(load_f)
        for key in load_dict:
            for key1 in load_dict[key]['VP']:
                dictipasn[load_dict[key]['VP'][key1][0]] = str(load_dict[key]['VP'][key1][1])
    print(len(dictipasn))
    ##extract info from pages
    with open('ip2AStransform.json', 'r') as load_f:
        load_dict1 = json.load(load_f)

    #bdrmapIT
    dictbdras = {}
    f2 = open("ip2as.txt", "r")
    lines = f2.readlines()
    for line3 in lines:
        ip = line3.split('\n')[0].split(' ')[0]
        asn = str(line3.split('\n')[0].split(' ')[2])
        if (ip in dictipasn):
            dictbdras[ip] = asn
            # num+=1
            # if(dictipasn[ip]!=asn):
            #     print(ip+','+dictipasn[ip]+','+asn)
            #     print(line3)
            #     dictipasn[ip]=asn
            #     numerror+=1
    print(len(dictbdras))
    print(len(load_dict1))
    num = 0
    for key in dictbdras:
        if (key not in load_dict1):
            num += 1
    print(num)

    # print(num)
    # print(numerror)
    # print(len(dictipasn))
    ####revise
    filelist = [
        '../VP2Geo/seedLGlistupdaterevise.json',
        '../VP2Geo/RelevantLGlistupdaterevise.json',
        '../VP2Geo/Relevant4LGlistupdaterevise.json',
        '../VP2Geo/Relevant3LGlistupdaterevise.json',
        '../VP2Geo/relevant2LGlistupdaterevise.json']
    for file in filelist:
        with open(file + '.json', 'r') as load_f:
            load_dict = json.load(load_f)
        for key in load_dict:
            for key1 in load_dict[key]['VP']:
                if (load_dict[key]['VP'][key1][0] in dictbdras):
                    load_dict[key]['VP'][key1][1] = dictbdras[load_dict[key]['VP'][key1][0]]
                if (load_dict[key]['VP'][key1][0] in load_dict1):
                    load_dict[key]['VP'][key1][1] = load_dict1[load_dict[key]['VP'][key1][0]]

        with open(file.split('VP2Geo/')[1].split('.json')[0] + "1.json", "w") as f:
            json.dump(load_dict, f)


def drawtierAS():
    dictseedip = {}
    with open("seedLGlistupdaterevise1.json", 'r') as load_f:
        load_dict = json.load(load_f)
    for key in load_dict:
        for key1 in load_dict[key]['VP']:
            try:
                dictseedip[load_dict[key]['VP'][key1][0]] = [load_dict[key]['VP'][key1][2],
                                                             load_dict[key]['VP'][key1][3],
                                                             float(load_dict[key]['VP'][key1][4]),
                                                             float(load_dict[key]['VP'][key1][5]),
                                                             load_dict[key]['VP'][key1][1]]
            except ValueError as e:
                print(load_dict[key])
    dictnewip = {}
    filelist = ['RelevantLGlistupdaterevise1.json',
                'Relevant2LGlistupdaterevise1.json',
                'Relevant3LGlistupdaterevise1.json',
                'Relevant4LGlistupdaterevise1.json']
    for ff in filelist:
        with open(ff, 'r') as load_f:
            load_dict = json.load(load_f)
        for key in load_dict:
            for key1 in load_dict[key]['VP']:
                if (load_dict[key]['VP'][key1][0] not in dictseedip):
                    dictnewip[load_dict[key]['VP'][key1][0]] = [load_dict[key]['VP'][key1][2],
                                                                load_dict[key]['VP'][key1][3],
                                                                float(load_dict[key]['VP'][key1][4]),
                                                                float(load_dict[key]['VP'][key1][5]),
                                                                load_dict[key]['VP'][key1][1]]

    # print(len(dictseedip))
    # print(len(dictnewip))

    #Categorizing the ASes of VPs according to network tier;
    dicttier={}
    file1 = open('tier.csv', 'r')
    csv_reader1 = csv.reader(file1)
    for row in csv_reader1:
        dicttier[row[1]]=row[2]
    seedAS={}
    for key in dictseedip:
        asn=dictseedip[key][4]
        if(asn in dicttier):
            seedAS[asn]=dicttier[asn]
        else:
            seedAS[asn]='stub'
    print(len(seedAS))
    # print(seedAS)
    seedAS1=0
    seedAS2=0
    seedASstub=0
    for key in seedAS:
        if(seedAS[key]=='1'):
            seedAS1+=1
        elif(seedAS[key]=='2'):
            seedAS2+=1
        else:
            seedASstub+=1
    # Categorizing the ASes of seed VPs according to network tier;
    print(seedAS1)
    print(seedAS2)
    print(seedASstub)



    dictnew={'stub':{},'1':{},'2':{}}
    newAS = {}
    for key in dictnewip:
        asn = dictnewip[key][4]
        if (asn in dicttier):
            newAS[asn] = dicttier[asn]
        else:
            newAS[asn] = 'stub'
        dictnew[newAS[asn]][asn]=''

    # Categorizing the ASes of obscure VPs according to network tier;
    print(len(newAS))
    print(len(dictnew['stub']))
    print(len(dictnew['1']))
    print(len(dictnew['2']))

    newAS1 = 0
    newAS2 = 0
    newASstub = 0
    for key in newAS:
        if(key in seedAS):
            continue
        if (newAS[key] == '1'):
            newAS1 += 1
        elif (newAS[key] == '2'):
            newAS2 += 1
        else:
            newASstub += 1
    #how many exclusive ASes
    print(newAS1)
    print(newAS2)
    print(newASstub)


    tier1=[7,2]
    tier2=[4,4]
    tierstub=[480,363]
    total_width,n=0.4,2
    width=total_width/n
    name=['  Tier-1 Tier-2 Stub tier\n1446 known VPs','  Tier-1 Tier-2 Stub tier\n910 obscure VPs']
    x1=[]
    x=range(0,2)
    plt.figure(figsize=(16,9))
    plt.grid(ls='--')
    for i in x:
        x1.append(x[i]+0.2)
    plt.xticks(x1,name)
    res1=plt.bar(x,tier1,width=width,label='Tier-1',color='gold')
    for bar in res1:
        bar.set_hatch('o')
    plt.text(x[0], tier1[0] + 0.05, tier1[0], ha='center', va='bottom',fontsize=30)
    plt.text(x[1], tier1[1] + 0.05, tier1[1], ha='center', va='bottom',fontsize=30)

    x2=[]
    for i in x:
        x2.append(x[i]+width)
    res2=plt.bar(x2,tier2,width=width,label='Tier-2',color='steelblue')
    for bar in res2:
        bar.set_hatch('\\')
    plt.text(x2[0], tier2[0] + 0.05, tier2[0], ha='center', va='bottom', fontsize=30)
    plt.text(x2[1], tier2[1] + 0.05, tier2[1], ha='center', va='bottom', fontsize=30)
    res5 = plt.bar(x2[1], 1, width=width, color='red', bottom=3)
    # for bar in res5:
    #     # bar.set_hatch('.')
    plt.text(x2[1], 3, str(1) + ' exclusive AS', ha='center', va='bottom', fontsize=20)


    x3=[]
    for i in x:
        x3.append(x[i]+width*2)
    res3=plt.bar(x3,tierstub,width=width,label='Stub tier',color='orchid')
    for bar in res3:
        bar.set_hatch('x')
    plt.text(x3[0], tierstub[0] + 0.05, tierstub[0], ha='center', va='bottom', fontsize=30)
    plt.text(x3[1], tierstub[1] + 0.05, tierstub[1], ha='center', va='bottom', fontsize=30)

    res4=plt.bar(x3[1], 287, width=width, color='red',bottom=76)
    # for bar in res4:
    #     bar.set_hatch('.')
    plt.text(x3[1], 120, str(287)+' exclusive ASes', ha='center', va='bottom', fontsize=20)
    # plt.legend(fontsize=30)
    plt.xlabel('(a)', fontsize=30)
    plt.xticks(fontsize=30)
    plt.yticks(fontsize=30)
    plt.tight_layout()
    plt.semilogy()
    plt.savefig('tier.png')
    plt.show()


def drawcustomcone():
    dictcustom = {}
    with open("customercone.json", 'r') as load_f:
        load_dict = json.load(load_f)
    for key in load_dict:
        try:
            dictcustom[key] = int(load_dict[key].split('Asns\":')[1].split('}}}}')[0])
        except IndexError as e:
            dictcustom[key]=1
            continue
    with open("customerconeArk.json", 'r') as load_f:
        load_dict = json.load(load_f)
    for key in load_dict:
        try:
            dictcustom[key] = int(load_dict[key].split('Asns\":')[1].split('}}}}')[0])
        except IndexError as e:
            dictcustom[key]=1
            continue
    with open("customerconeRouteviews.json", 'r') as load_f:
        load_dict = json.load(load_f)
    for key in load_dict:
        try:
            dictcustom[key] = int(load_dict[key].split('Asns\":')[1].split('}}}}')[0])
        except IndexError as e:
            dictcustom[key] = 1
            continue
    with open("customerconeRIPE.json", 'r') as load_f:
        load_dict = json.load(load_f)
    for key in load_dict:
        try:
            dictcustom[key] = int(load_dict[key].split('Asns\":')[1].split('}}}}')[0])
        except IndexError as e:
            dictcustom[key] = 1
            continue
    print(len(dictcustom))



    dictseedAS = {}
    with open(
            "seedLGlistupdaterevise1.json",
            'r') as load_f:
        load_dict = json.load(load_f)
    for key in load_dict:
        for key1 in load_dict[key]['VP']:

            dictseedAS[load_dict[key]['VP'][key1][1]] = dictcustom[load_dict[key]['VP'][key1][1]]

    print('seed')
    ##known VPs are distributed in 491  ASes
    print(len(dictseedAS))

    dictnewAS={}
    filelist = ['RelevantLGlistupdaterevise1.json',
                'Relevant2LGlistupdaterevise1.json',
                'Relevant3LGlistupdaterevise1.json',
                'Relevant4LGlistupdaterevise1.json']
    for ff in filelist:
        with open(ff, 'r') as load_f:
            load_dict = json.load(load_f)
            for key in load_dict:
                for key1 in load_dict[key]['VP']:
                    if(load_dict[key]['VP'][key1][1] not in dictseedAS):
                        dictnewAS[load_dict[key]['VP'][key1][1]] = dictcustom[load_dict[key]['VP'][key1][1]]



    dictarkas={}
    file1 = open('Ark.csv', 'r')
    csv_reader1 = csv.reader(file1)
    for row in csv_reader1:
        dictarkas[row[1]] = dictcustom[row[1]]
    print('ARK')
    #ark VPs are distributed in 115  ASes
    print(len(dictarkas))

    dictripeAS={}
    file1 = open('./RIPERIS/RIPEpeeras.csv', 'r')
    csv_reader1 = csv.reader(file1)
    for row in csv_reader1:
        dictripeAS[row[0]] = dictcustom[row[0]]
    print('RIPE')
    #RIPE VPs are distributed in 520  ASes

    print(len(dictripeAS))

    dictrouteViews = {}
    file1 = open('./RouteViews/peeras.csv', 'r')
    csv_reader1 = csv.reader(file1)
    for row in csv_reader1:
        dictrouteViews[row[0]] = dictcustom[row[0]]
    print('Route')
    #routeviews VPs are distributed in 270  ASes

    print(len(dictrouteViews))

    seedconenum = []
    newconenum = []
    arknum=[]
    ripenum=[]
    routeviewsnum=[]
    for key in dictseedAS:
        if(key not in dictnewAS and key not in dictarkas and key not in dictripeAS and key not in dictrouteViews):
            seedconenum.append((dictseedAS[key]))
    for key in dictnewAS:
        if (key not in dictseedAS and key not in dictarkas and key not in dictripeAS and key not in dictrouteViews):
            newconenum.append((dictnewAS[key]))
    for key in dictarkas:
        if (key not in dictseedAS and key not in dictnewAS and key not in dictripeAS and key not in dictrouteViews):
            arknum.append((dictarkas[key]))
    for key in dictripeAS:
        if (key not in dictseedAS and key not in dictnewAS and key not in dictarkas and key not in dictrouteViews):
            ripenum.append((dictripeAS[key]))
    for key in dictrouteViews:
        if (key not in dictseedAS and key not in dictnewAS and key not in dictarkas and key not in dictripeAS):
            routeviewsnum.append((dictrouteViews[key]))

    #The number of ASes and exclusive ASes covered by VPs of each platform.
    print(len(seedconenum))
    print(len(newconenum))
    print(len(arknum))
    print(len(ripenum))
    print(len(routeviewsnum))

    plt.figure(figsize=(16, 9))
    sorted_data1 = np.sort(seedconenum)
    yvals1 = np.arange(len(sorted_data1)) / float(len(sorted_data1) - 1)
    sorted_data2 = np.sort(newconenum)
    yvals2 = np.arange(len(sorted_data2)) / float(len(sorted_data2) - 1)
    sorted_data3 = np.sort(arknum)
    yvals3 = np.arange(len(sorted_data3)) / float(len(sorted_data3) - 1)
    sorted_data4 = np.sort(ripenum)
    yvals4 = np.arange(len(sorted_data4)) / float(len(sorted_data4) - 1)
    sorted_data5 = np.sort(routeviewsnum)
    yvals5 = np.arange(len(sorted_data5)) / float(len(sorted_data5) - 1)
    plt.plot(sorted_data2, yvals2, linestyle='--', label="AS exclusively covered by the obsecure VPs", linewidth=4, color='red')
    plt.legend(loc='lower right', fontsize=25)
    plt.plot(sorted_data1, yvals1, linestyle='-', label="AS exclusively covered by the known VPs", linewidth=4, color='purple')
    plt.legend(loc='lower right', fontsize=25)
    plt.plot(sorted_data3, yvals3, linestyle='--', label="AS exclusively covered by Ark VPs", linewidth=4, color='blue')
    plt.legend(loc='lower right', fontsize=25)
    plt.plot(sorted_data4, yvals4, linestyle='--', label="AS exclusively covered by RIPE RIS VPs", linewidth=4, color='green')
    plt.legend(loc='lower right', fontsize=25)
    plt.plot(sorted_data5, yvals5, linestyle='--', label="AS exclusively covered by RouteViews VPs", linewidth=4, color='orange')
    plt.legend(loc='lower right', fontsize=25)

    # ax.tick_params(direction='in', top=True, right=True, labeltop=False, labelright=False, labelsize=10)
    plt.grid(ls='--')

    plt.xlabel('Customer cone size\n(b)', fontsize=30)
    plt.ylabel('CDF', fontsize=30)
    plt.xticks(fontsize=30)
    plt.yticks(fontsize=30)
    plt.semilogx()
    # plt.axis([0.001, 6, 0, 1])

    # plt.xlim(0, 40)

    # plt.ylim(0.5, 1)
    plt.tight_layout()

    plt.savefig("LGcustom.png")
    plt.show()



if __name__ == '__main__':
    # extractASinfo()
    # obtainVP2AS()
    # revise()
    #Figure 5(a) Categorizing the ASes of VPs according to network tier;
    # drawtierAS()
    ##Table 5 The number of ASes and exclusive ASes covered by VPs of each platform.
    ##and figure 6(b) The distribution of customer cone sizes of ASes covered by different VP datasets.
    drawcustomcone()