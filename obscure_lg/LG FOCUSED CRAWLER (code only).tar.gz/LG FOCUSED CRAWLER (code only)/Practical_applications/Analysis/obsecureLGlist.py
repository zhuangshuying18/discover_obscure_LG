import json
def calobscureVPs():
    dictseedip={}
    with open(
            "../Automatable_tool/initial/request_response/seedLGlist.json",
            'r') as load_f:
        load_dict = json.load(load_f)
    for key in load_dict:
        for key1 in load_dict[key]['VP']:
            try:
                dictseedip[load_dict[key]['VP'][key1][0]] = [load_dict[key]['VP'][key1][2],load_dict[key]['VP'][key1][3],(load_dict[key]['VP'][key1][4]),(load_dict[key]['VP'][key1][5]),load_dict[key]['VP'][key1][1]]
            except ValueError as e:
                print(load_dict[key])
    dictnewip={}
    filelist=['../Automatable_tool/initial/request_response/RelevantLGlist.json',
              '../Automatable_tool/second_iteration/request_response/Relevant2LGlist.json',
              '../Automatable_tool/third_iteration/request_response/Relevant3LGlist.json',
              '../Automatable_tool/forth_iteration/request_response/Relevant4LGlist.json' ]
    for ff in filelist:
        with open(ff, 'r') as load_f:
            load_dict = json.load(load_f)
        for key in load_dict:
            for key1 in load_dict[key]['VP']:
                if(load_dict[key]['VP'][key1][0] not in dictseedip):
                    dictnewip[load_dict[key]['VP'][key1][0]] = [load_dict[key]['VP'][key1][2], load_dict[key]['VP'][key1][3],(load_dict[key]['VP'][key1][4]),(load_dict[key]['VP'][key1][5]),load_dict[key]['VP'][key1][1]]

    print(len(dictseedip))
    print(len(dictnewip))
if __name__ == '__main__':
    calobscureVPs()