import json
import json
import csv
import json
import csv
import matplotlib.pyplot as plt


def calsupportedcommands():
    dicttraceroute = {}
    dictping={}
    dictseedip={}
    #show-route,bgproute,advertised-routes
    dictbgproute={}
    #bgpsummary4,summary
    dictbgpsummary={}
    #as-path-regex
    dictbgpregex={}
    dictsummary={}
    with open(
            "../Automatable_tool/initial/request_response/seedLGlist.json",
            'r') as load_f:
        load_dict = json.load(load_f)
    for key in load_dict:
        for key1 in load_dict[key]['VP']:
            dictseedip[load_dict[key]['VP'][key1][0]]=''
            str1=','.join(load_dict[key]['Commands'])
            if ('ping' in str1.lower()):
                dictping[load_dict[key]['VP'][key1][0]]=''
            if('trace' in str1.lower()):
                dicttraceroute[load_dict[key]['VP'][key1][0]] = ''
            if ('regex' in str1.lower()):
                dictbgpregex[load_dict[key]['VP'][key1][0]] = ''
            if ('summary' in str1.lower()):
                dictbgpsummary[load_dict[key]['VP'][key1][0]] = ''
                dictsummary[key] = ''
            if('show-route' in str1.lower() or 'routes' in str1.lower() or 'bgproute' in str1.lower() or 'bgp' in str1.lower().split(',') or 'bgp(ixp)' in str1.lower() ):
                dictbgproute[load_dict[key]['VP'][key1][0]] = ''



    print(len(dictseedip))
    print(len(dictping))
    print(len(dictbgproute))
    print(len(dictbgpsummary))
    print(len(dictbgpregex))
    print(len(dicttraceroute))
    # print(len(dictsummary))

    dictnewping = {}
    dictnewtrace = {}
    dictnewbgproute={}
    #bgpsummary4,summary
    dictnewsummary={}
    dictnewbgpsummary={}
    #as-path-regex
    dictnewbgpregex={}
    filelist = [
        '../Automatable_tool/initial/request_response/RelevantLGlist.json',
        '../Automatable_tool/second_iteration/request_response/Relevant2LGlist.json',
        '../Automatable_tool/third_iteration/request_response/Relevant3LGlist.json',
        '../Automatable_tool/forth_iteration/request_response/Relevant4LGlist.json']
    for ff in filelist:
        with open(ff, 'r') as load_f:
            load_dict = json.load(load_f)
        for key in load_dict:
            for key1 in load_dict[key]['VP']:
                if(load_dict[key]['VP'][key1][0] in dictseedip):
                    continue
                str1 = ','.join(load_dict[key]['Commands'])
                if ('ping' in str1.lower()):
                    dictnewping[load_dict[key]['VP'][key1][0]] = ''
                if ('trace' in str1.lower()):
                    dictnewtrace[load_dict[key]['VP'][key1][0]] = ''
                if ('regex' in str1.lower()):
                    dictnewbgpregex[load_dict[key]['VP'][key1][0]] = ''
                if ('summary' in str1.lower()):
                    dictnewbgpsummary[load_dict[key]['VP'][key1][0]] = ''
                if ('show-route' in str1.lower() or 'routes' in str1.lower() or 'bgproute' in str1.lower() or 'bgp' in str1.split(
                        ',') or 'bgp(ixp)' in str1.lower()):
                    dictnewbgproute[load_dict[key]['VP'][key1][0]] = ''


    print(len(dictnewping))
    print(len(dictnewbgproute))
    print(len(dictnewbgpsummary))
    print(len(dictnewbgpregex))
    print(len(dictnewtrace))


def draw():

    tier1=[1431,1413,1278,452,198]
    tier2=[858,853,346,78,44]
    total_width, n = 0.8, 3
    width = total_width / n
    name = ['Ping','Traceroute', 'BGP\nroutes','BGP\nsummary','BGP\nregex']
    x1 = []
    x = range(0, 5)
    plt.figure(figsize=(16, 9))
    plt.grid(ls='--')
    for i in x:
        x1.append(x[i] + 0.2)
    plt.xticks(x1, name)
    res1 = plt.bar(x, tier1, width=width, label='1446 known automatable VPs', color='gold')
    for bar in res1:
        bar.set_hatch('.')
    plt.text(x[0], tier1[0] + 0.05, tier1[0], ha='center', va='bottom', fontsize=30)
    plt.text(x[1], tier1[1] + 0.05, tier1[1], ha='center', va='bottom', fontsize=30)
    plt.text(x[2], tier1[2] + 0.05, tier1[2], ha='center', va='bottom', fontsize=30)
    plt.text(x[3], tier1[3] + 0.05, tier1[3], ha='center', va='bottom', fontsize=30)
    plt.text(x[4], tier1[4] + 0.05, tier1[4], ha='center', va='bottom', fontsize=30)

    x2 = []
    for i in x:
        x2.append(x[i] + width)
    res2 = plt.bar(x2, tier2, width=width, label='910 obscure automatable VPs', color='steelblue')
    for bar in res2:
        bar.set_hatch('\\')
    plt.text(x2[0], tier2[0] + 0.05, tier2[0], ha='center', va='bottom', fontsize=30)
    plt.text(x2[1], tier2[1] + 0.05, tier2[1], ha='center', va='bottom', fontsize=30)
    plt.text(x2[2], tier2[2] + 0.05, tier2[2], ha='center', va='bottom', fontsize=30)
    plt.text(x2[3], tier2[3] + 0.05, tier2[3], ha='center', va='bottom', fontsize=30)
    plt.text(x2[4], tier2[4] + 0.05, tier2[4], ha='center', va='bottom', fontsize=30)

    plt.legend(fontsize=30)
    # plt.xlabel('Measurement commands', fontsize=30)
    plt.xticks(fontsize=30)
    plt.yticks(fontsize=30)
    plt.tight_layout()
    # plt.semilogy()
    plt.ylim(0,2000)
    plt.savefig('commands.png')
    plt.show()
if __name__ == '__main__':
    # calsupportedcommands()

    draw()