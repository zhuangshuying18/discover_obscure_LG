import json
import csv
import random

import datetime
import threading

import requests
from selenium.webdriver.support.select import Select
import re
import json
from bs4 import BeautifulSoup as bs
def bgpsummarymeasurement(filelist,filepingcmd,output):
    dicturl = {}
    dicturlip = {}
    dictcmd = {}
    for i in range(0,len(filelist)):
        print(i)
        with open(filelist[i], 'r') as load_f:
            load_dict = json.load(load_f)
        for key in load_dict:
            for key1 in load_dict[key]['VP']:
                if (load_dict[key]['VP'][key1][0] == '39.99.233.63'):
                    continue
                str1 = ','.join(load_dict[key]['Commands'])
                if ('summary' in str1.lower()):
                    # print(key)
                    dicturl[key] = load_dict[key]['Commands']
                    dicturlip[load_dict[key]['VP'][key1][0]] = ''
                    # print(str1)


        file1 = open( filepingcmd[i], 'r')
        csv_reader1 = csv.reader(file1)
        for row in csv_reader1:
            com = ','.join(row).split(',|zsy|')
            if (com[0] in dicturl):
                str1 = com[0] + ',|zsy|' + com[1] + ',|zsy|'
                item = ''
                for c in dicturl[com[0]]:
                    if ('summary' in c):
                        item = c
                        break
                str1 += com[2].replace('ping', item) + ',|zsy|' + com[4]
                dictcmd[str1] = ''


    # file1 = open(output, 'w')
    # for key in dictcmd:
    #     file1.writelines(key + '\n')

import time
def dosomething(bgpcmdfile,st,filist):
    dictpre={}
    csv.field_size_limit(500 * 1024 * 1024)
    file1 = open(st+'resulls.csv', 'r')
    csv_reader1 = csv.reader((line.replace('\0', '') for line in file1))
    for row in csv_reader1:
        if (',|zhuangshuying|' in ','.join(row)):
            dictpre[','.join(row).split(',|zhuangshuying|')[0]] = ''
    file1 = open(st+'errors.csv', 'r')
    csv_reader1 = csv.reader((line.replace('\0', '') for line in file1))
    for row in csv_reader1:
        if (',|zhuangshuying|' in ','.join(row)):
            dictpre[','.join(row).split(',|zhuangshuying|')[0]] = ''


    dicturl = []
    dicturlinfo={}
    file1 = open(bgpcmdfile, 'r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    for row in csv_reader1:
        if (','.join(row) not in dictpre):
            dicturl.append(','.join(row))
            dicturlinfo[','.join(row).split(',|zsy|')[0]]=''

    random.shuffle(dicturl)
    print(len(dicturl))
    dicturlcontent = {}
    for fl in filist:
        file1 = open(fl, 'r')
        csv_reader1 = csv.reader(file1)
        csv.field_size_limit(500 * 1024 * 1024)
        for row in csv_reader1:
            urlpre = ','.join(row).split(',|zhuangshuying|')[0]
            try:
                urlnew = ','.join(row).split(',|zhuangshuying|')[1]
            except IndexError as e:
                continue
            if (urlpre not in dicturlinfo):
                continue
            dicturlcontent[urlpre] = urlnew

    import eventlet
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--disable-dev-shm-usage')

    driver = webdriver.Chrome(chrome_options=chrome_options)

    driver.set_page_load_timeout(150)
    driver.set_script_timeout(150)
    f1 = open(st+'resulls.csv', 'a')
    f2 = open(st+'errors.csv', 'a')

    for num in range(0, len(dicturl)):

        ###每个搜索命令
        cmd = dicturl[num]
        ##先打开
        cmdlist = cmd.split(',|zsy|')
        print(cmdlist)
        if (cmdlist[0] in dicturlcontent):
            try:
                url = dicturlcontent[cmdlist[0]]
                driver.get(url)
                form = driver.find_elements_by_tag_name('form')[int(cmdlist[1])]
                for m in range(2, len(cmdlist)):
                    if (cmdlist[m] != ' '):
                        name = cmdlist[m].split('=')[0]
                        type = cmdlist[m].split('=')[1]
                        value = cmdlist[m].split('=')[2]
                        if (type == 'radio'):
                            elem = driver.find_elements_by_name(name)
                            for i in elem:
                                if i.get_attribute('value') == value:
                                    if (not i.is_selected()):
                                        i.click()
                                        time.sleep(1)
                                    break
                        elif (type == 'checkbox'):
                            elem = driver.find_elements_by_name(name)
                            for i in elem:
                                if i.get_attribute('value') == value:
                                    if (not i.is_selected()):
                                        i.click()
                                        time.sleep(1)
                                    break
                                else:
                                    if (i.is_selected()):
                                        i.click()

                        elif (type == 'select'):
                            selector = Select(driver.find_element_by_name(name))
                            selector.select_by_value(value)  # 通过value属性值进行选择
                        else:
                            ##清空默认的值
                            elem = driver.find_element_by_name(name)
                            elem.clear()
                            elem.send_keys(value)
                            # # ##radio

                form.submit()
                time.sleep(1)
                brr = str(driver.page_source.replace('\n', ' ').replace('\t', ' '))
                f1.writelines(',|zsy|'.join(
                    cmdlist) +  ',|zhuangshuying|' + brr + '\n')
                f1.flush()


            except Exception as e:
                f2.writelines(',|zsy|'.join(cmdlist) +  ',|zhuangshuying|' + str(
                    e).replace('\n', ' ').replace('\t', ' ') + '\n')
                f2.flush()
                continue

    driver.quit()

def showbgpneighborlink(summarywebpage,output):
    dicturl={}
    file1 = open(summarywebpage, 'r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    for row in csv_reader1:
        url = ','.join(row).split(',|zsy|')[0]
        dicturl[url] = []

    file1 = open(summarywebpage, 'r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    for row in csv_reader1:
        url = ','.join(row).split(',|zsy|')[0]
        print(url)
        try:
            html = ','.join(row).split(',|zhuangshuying|')[1]
        except IndexError as e:
            continue
        if (html.replace(' ', '') == ''):
            continue
        content = html
        soup = bs(content, 'html.parser')
        for link in soup.findAll("a", href=re.compile("^(/lg/|\?router)")):
            if link.attrs['href'] is not None:

                str1 = ''
                if ('/lg/' in link.attrs['href']):
                    str1 = url.split('://')[0] + '://' + url.split('://')[1].split('/')[0] + link.attrs['href']
                elif ('?router' in link.attrs['href']):
                    str1 = url.split('://')[0] + '://' + url.split('://')[1].split('/')[0] + '/' + link.attrs['href']
                # print(str1)
                if (str1 not in dicturl[url]):
                    dicturl[url].append(str1)

    with open(output, "w") as f:
        json.dump(dicturl, f)


headers = {
            'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36',
            'accept-language': 'zh-CN,zh;q=0.9',
            'cache-control': 'max-age=0',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8'
        }
def getneighborIPinfo(st,urllist,be,ed,thread_index):
    f1 = open(st + str(int(thread_index)) + '.csv', 'a')
    for num in range(be, ed):
        url = urllist[num]
        try:
            requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)
            r = requests.get(url=url,
                             headers=headers,
                             allow_redirects=False,
                             verify=False,
                             timeout=60)
            r.raise_for_status()
            r.encoding = r.apparent_encoding
            content = r.text

            if ('301 Moved Permanently'.lower() in content.lower() or 'Object moved'.lower() in content.lower()):
                print(url)
                url1 = 'https://' + url.split('://')[1]
                r = requests.get(url=url1,
                                 headers=headers,
                                 allow_redirects=False,
                                 verify=False,
                                 timeout=60)
                r.raise_for_status()
                r.encoding = r.apparent_encoding
                content = r.text
                f1.writelines(
                    url + ',|zhuangshuying|' + url1 + ',|zhuangshuying|' + content.replace('\n', ' ').replace('\t',
                                                                                                              ' ') + '\n')
                f1.flush()
            else:
                f1.writelines(
                    url + ',|zhuangshuying|' + url + ',|zhuangshuying|' + content.replace('\n', ' ').replace('\t',
                                                                                                             ' ') + '\n')
                f1.flush()

        except Exception as e:
            print(url)
            print(e)
            continue


def collectneighborIPinfo(hyperlinkfile,st):
    dicturl = []
    with open(hyperlinkfile, 'r') as load_f:
        load_dict = json.load(load_f)
    for key in load_dict:
        for key1 in load_dict[key]:
            dicturl.append(key1)

    random.shuffle(dicturl)
    ##将输入节点分成10分
    print(len(dicturl))
    d = 10
    num = int(len(dicturl) / d)
    for i in range(d):
        if (i != (d - 1)):
            t = threading.Thread(target=getneighborIPinfo, args=(st,dicturl, num * i, num * (i + 1), i))
            t.start()
        else:
            t = threading.Thread(target=getneighborIPinfo,
                                 args=(st,dicturl, num * i, len(dicturl), i))
            t.start()
def mearge(st,output):
    file=open(output,'a')
    for i in range(0, 10):
        csv.field_size_limit(500 * 1024 * 1024)
        file1 = open(st + str(i) + '.csv', 'r')
        csv_reader1 = csv.reader((line.replace('\0', '') for line in file1))
        for row in csv_reader1:
            file.writelines(','.join(row)+'\n')

def showbgpneigborlinknew(prefile,pagefile,output):
    dicturl = {}
    with open(prefile, 'r') as load_f:
        load_dict = json.load(load_f)
    for key in load_dict:
        for key1 in load_dict[key]:
            dicturl[key1] = []

    file1 = open(pagefile, 'r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    for row in csv_reader1:
        url = ','.join(row).split(',|zhuangshuying|')[0]
        try:
            html = ','.join(row).split(',|zhuangshuying|')[2]
        except IndexError as e:
            continue
        if (html.replace(' ', '') == ''):
            continue
        content = html
        if ('weight path' in content.lower()):
            print(url)
            continue
        soup = bs(content, 'html.parser')
        for link in soup.findAll("a", href=re.compile("^(/lg/|\?router)")):
            if link.attrs['href'] is not None:

                str1 = ''
                if ('/lg/' in link.attrs['href']):
                    str1 = url.split('://')[0] + '://' + url.split('://')[1].split('/')[0] + link.attrs['href']
                elif ('?router' in link.attrs['href']):
                    str1 = url.split('://')[0] + '://' + url.split('://')[1].split('/')[0] + '/' + link.attrs['href']
                # print(str1)
                if (str1 not in dicturl[url]):
                    dicturl[url].append(str1)

    with open(output, "w") as f:
        json.dump(dicturl, f)



def extractASpath(filein, filecontent,fileout):
    dicturl={}
    with open(filein, 'r') as load_f:
        load_dict = json.load(load_f)
    for key in load_dict:
        for key1 in load_dict[key]:
            dicturl.append(key1)
    print(len(dicturl))
    file1 = open(filecontent, 'r')
    csv_reader1 = csv.reader(file1)
    csv.field_size_limit(500 * 1024 * 1024)
    for row in csv_reader1:
        url = ','.join(row).split(',|zhuangshuying|')[0]
        if (url not in dicturl):
            continue
        try:
            html = ','.join(row).split(',|zhuangshuying|')[2]
        except IndexError as e:
            continue
        if (html.replace(' ', '') == ''):
            continue
        content = html.lower()
        if ('weight path' in content.lower() or 'as path' in content.lower()):
            print(url)

            import re
            pattern = re.compile(r'(\d+ )+[i\?]')
            aspath = pattern.search(content)
            while (aspath):
                list1 = aspath.group()
                print(list1)
                dicturl[url][list1] = ''
                content = content[aspath.end():]
                aspath = pattern.search(content)

    with open(fileout, "w") as f:
        json.dump(dicturl, f)

def mergeandgetlink(file1,file2,output ):
    ##IPv4

    dictnurl = {}
    with open(file1, 'r') as load_f:
        load_dict = json.load(load_f)
    for key in load_dict:
        if (load_dict[key] != {}):
            if ('protocol=ipv4' in key.lower()):
                for key1 in load_dict[key]:
                    dictnurl[key1] = ''

    with open(file2, 'r') as load_f:
        load_dict = json.load(load_f)
    for key in load_dict:
        if (load_dict[key] != {}):
            if ('protocol=ipv4' in key.lower()):
                for key1 in load_dict[key]:
                    dictnurl[key1] = ''

    """ Parse BGP paths from a RIB file.

           Remove duplicated ASes, an artifact of BGP path prepending.
           Sanitize the BGP paths: remove route server ASes;
                                   remove paths containing reserved ASes;
                                   remove paths with AS loops.
           """
    for key in dictnurl:
        # remove prepended ASes
        # print(key)
        asn_list = key.split(' ')
        if ('i' in asn_list):
            asn_list.remove('i')
        if ('?' in asn_list):
            asn_list.remove('?')
        if ('0' == asn_list[0]):
            asn_list.remove('0')

        asn_list = [v for i, v in enumerate(asn_list)
                    if i == 0 or v != asn_list[i - 1]]
        # print(asn_list)
        asn_set = set(asn_list)
        str1 = ' '.join(asn_list)
        # remove poisoned paths with AS loops
        if len(asn_set) == 1 or not len(asn_list) == len(asn_set):
            continue
        else:
            tag = 0
            for asn in asn_list:
                asn = int(asn)
                # reserved ASN
                if asn == 0 or asn == 23456 or asn >= 394240 \
                        or (61440 <= asn <= 131071) \
                        or (133120 <= asn <= 196607) \
                        or (199680 <= asn <= 262143) \
                        or (263168 <= asn <= 327679) \
                        or (328704 <= asn <= 393215):
                    tag = 1
                    break
            if (tag == 0):
                dictnurl[key] = str1

    dictlink = {}
    for key in dictnurl:
        if (load_dict[key] != ""):
            list1=load_dict[key].split(' ')
            for i in range(0,len(list1)-1):
                link1=list1[i]+'-'+list1[i+1]
                link2=list1[i+1]+'-'+list1[i]
                if(link1 not in dictlink and link2 not in dictlink):
                    dictlink[link1]=''
    print(len(dictlink))
    with open(output, "w") as f:
        json.dump(dictlink, f)
    print(len(dictlink))

def analysis():
    ##we counduct analysis here

    filelist=['bgpseedlink.json',
              '../BGPdata/RIPElink.json',
              '../BGPdata/RVlink.json',
              'bgplink.json']
    for file in filelist:
        dictAS={}
        with open(file, 'r') as load_f:
            load_dict = json.load(load_f)
        for key in load_dict:
            dictAS[key.split('-')[0]] = ''
            dictAS[key.split('-')[1]] = ''
        print(len(load_dict))
        print(len(dictAS))
    #exclusive ASes and AS links

    dictseedAS={}
    dictseedlink={}
    with open('bgpseedlink.json', 'r') as load_f:
        load_dict = json.load(load_f)
    for key in load_dict:
        dictseedlink[key]=''
        dictseedAS[key.split('-')[0]] = ''
        dictseedAS[key.split('-')[1]] = ''


    dictripeAS={}
    dictripelink={}

    with open('../BGPdata/RIPElink.json', 'r') as load_f:
        load_dict = json.load(load_f)
    for key in load_dict:
        dictripelink[key] = ''
        dictripeAS[key.split('-')[0]] = ''
        dictripeAS[key.split('-')[1]] = ''


    dictrouteviewsAS={}
    dictrouteviewlink={}
    with open('../BGPdata/RVlink.json', 'r') as load_f:
        load_dict = json.load(load_f)
    for key in load_dict:
        dictrouteviewlink[key] = ''
        dictrouteviewsAS[key.split('-')[0]] = ''
        dictrouteviewsAS[key.split('-')[1]] = ''


    dictnewAS={}
    dictnewlink={}
    with open('bgplink.json', 'r') as load_f:
        load_dict = json.load(load_f)
    for key in load_dict:
        dictnewlink[key] = ''
        dictnewAS[key.split('-')[0]] = ''
        dictnewAS[key.split('-')[1]] = ''


    numAS=0
    numlink=0
    for key in dictseedAS:
        if(key not in dictrouteviewsAS and key not in dictripeAS and key not in dictnewAS):
            numAS+=1
    for key in dictseedlink:
        link2 = key.split('-')[1] + '-' + key.split('-')[0]
        if (key not in dictrouteviewlink and key not in dictripelink and key not in dictnewlink
        and link2 not in dictrouteviewlink and link2 not in dictripelink and link2 not in dictnewlink):
            numlink+=1
    ##known LG VPs: obtain 247 exclusive ASes and 8,318 exclusive AS links
    print(numAS)
    print(numlink)


    numAS=0
    numlink=0
    for key in dictnewAS:
        if(key not in dictrouteviewsAS and key not in dictripeAS and key not in dictseedAS):
            numAS+=1
    for key in dictnewlink:
        link2 = key.split('-')[1] + '-' + key.split('-')[0]
        if (key not in dictrouteviewlink and key not in dictripelink and key not in dictseedlink
        and link2 not in dictrouteviewlink and link2 not in dictripelink and link2 not in dictseedlink):
            numlink+=1
    ##Obscure LG VPs: obtain 10 exclusive ASes and 1,428 exclusive AS links
    print(numAS)
    print(numlink)

    numAS = 0
    numlink = 0
    for key in dictripeAS:
        if (key not in dictrouteviewsAS and key not in dictnewAS and key not in dictseedAS):
            numAS += 1
    for key in dictripelink:
        link2 = key.split('-')[1] + '-' + key.split('-')[0]
        if (key not in dictrouteviewlink and key not in dictnewlink and key not in dictseedlink
                and link2 not in dictrouteviewlink and link2 not in dictnewlink and link2 not in dictseedlink):
            numlink += 1
    ##rIPE RIS LG VPs: obtain 12 exclusive ASes and 37383 exclusive AS links
    print(numAS)
    print(numlink)

    numAS = 0
    numlink = 0
    for key in dictrouteviewsAS:
        if (key not in dictripeAS and key not in dictnewAS and key not in dictseedAS):
            numAS += 1
    for key in dictrouteviewlink:
        link2 = key.split('-')[1] + '-' + key.split('-')[0]
        if (key not in dictripelink and key not in dictnewlink and key not in dictseedlink
                and link2 not in dictripelink and link2 not in dictnewlink and link2 not in dictseedlink):
            numlink += 1
    ##rIPE RIS LG VPs: obtain 271 exclusive ASes and 85450 exclusive AS links
    print(numAS)
    print(numlink)

if __name__ == '__main__':
    filelistseed=['../../Analysis/coverage/VP2AS/seedLGlistupdaterevise1.json']
    filelistrelevant=['../../Analysis/coverage/VP2AS/RelevantLGlistupdaterevise1.json',
        '../../Analysis/coverage/VP2AS/Relevant2LGlistupdaterevise1.json',
        '../../Analysis/coverage/VP2AS/Relevant3LGlistupdaterevise1.json',
        '../../Analysis/coverage/VP2AS/Relevant4LGlistupdaterevise1.json'    ]

    filepingcmdseed=['../../Automatable_tool/initial/request_response/pingseedcmd.csv']
    filepingcmdrelev=['../../Automatable_tool/initial/request_response/pingcmd.csv',
                      '../../Automatable_tool/second_iteration/request_response/pingcmd.csv',
                     '../../Automatable_tool/third_iteration/request_response/pingcmd.csv',
                      '../../Automatable_tool/forth_iteration/request_response/pingcmd.csv']
    # translate {\em show ip bgp summary} measurement requests into the action of filling in the input fields of the corresponding form element with specific values (see bgpcmd.csv and bgpseedcmd.csv).

    # bgpsummarymeasurement(filelistseed,filepingcmdseed,'bgpseedcmd.csv')
    # bgpsummarymeasurement(filelistrelevant,filepingcmdrelev,'bgpcmd.csv')
    #
    # # Then, we automatically issue  {\em show ip bgp summary} measurement requests to ask each VP to show ip bgp summary.
    fillist = ["../../../Classification procedure/Get relevant URLs/initial/LGallcontent.csv",
                '../../../Classification procedure/Get relevant URLs/second_iteration/LGallcontent.csv',
                '../../../Classification procedure/Get relevant URLs/third_iteration/LGallcontent.csv',
                '../../../Classification procedure/Get relevant URLs/forth_iteration/LGallcontent.csv']

    # dosomething('bgpcmd.csv','bgp_',fillist)
    fillist=['../../../Classification procedure/Get relevant URLs/initial/LGallcontent.csv']
    # dosomething('bgpseedcmd.csv','bgpseed_',fillist)
    #
    #
    # Then, by visiting the hyperlink of each neighbor IP, we can ask the VP to run show bgp neighbor ip command to collect detailed information about the neighbor IP, including a hyperlink for showing its advertised (or received) routes
    # extract hyperlink
    # showbgpneighborlink("bgp_resulls.csv","bgpneighbor.json")
    # showbgpneighborlink("bgpseed_resulls.csv","bgpseedneighbor.json")
    #
    # ##visit the hyperlink to ask the VP to run show bgp neighbor ip command to collect detailed information about the neighbor IP, including a hyperlink for showing its advertised (or received) routes (see).
    #
    # collectneighborIPinfo('bgpneighbor.json', 'bgpneighbor_content')
    # mearge('bgpneighbor_content','bgpneighbor_content.csv')
    # collectneighborIPinfo('bgpseedneighbor.json','bgpseedneighbor_content')
    # mearge('bgpseedneighbor_content','bgpseedneighbor_content.csv')
    #
    #  By further extracting the hyperlinks, we send requests to the VP to run the command to collect advertised (or received) BGP routes
    #  extract hyperlink
    # showbgpneigborlinknew('bgpneighbor.json','bgpneighbor_content.csv',"bgpneighbor1.json")
    # showbgpneigborlinknew('bgpseedneighbor.json','bgpseedneighbor_content.csv',"bgpseedneighbor1.json")
    # # we send requests to the VP to run the command to collect advertised (or received) BGP routes.
    # collectneighborIPinfo('bgpneighbor1.json', 'bgpneighbor_content_1')
    # mearge('bgpneighbor_content_1', 'bgpneighbor_content_1.csv')
    # collectneighborIPinfo('bgpseedneighbor1.json', 'bgpseedneighbor_content_1')
    # mearge('bgpseedneighbor_content_1', 'bgpseedneighbor_content_1.csv')
    #
    # ##After collecting all data, we can extrct AS paths now
    # extractASpath('bgpneighbor.json','bgpneighbor_content.csv','bgpneighborasspath.json')
    # extractASpath('bgpneighbor1.json','bgpneighbor_content_1.csv','bgpneighbor1asspath.json')
    # extractASpath('bgpseedneighbor.json','bgpseedneighbor_content.csv','bgpseedneighborasspath.json')
    # extractASpath('bgpseedneighbor1.json','bgpseedneighbor_content_1.csv','bgpseedneighbor1asspath.json')
    # merge and getbgplink
    # mergeandgetlink('bgpneighbor1asspath.json','bgpneighborasspath.json',"bgplink.json")
    # mergeandgetlink('bgpseedneighbor1asspath.json','bgpseedneighborasspath.json',"bgpseedlink.json")
    #

    #analyzing the number of observed and exclusive ASes, AS links extracted from each dataset.
    #Table6: the number of observed and exclusive ASes, AS links extracted from each dataset.
    analysis()

