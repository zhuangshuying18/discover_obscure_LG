import csv
import csv
import json

import re

from collections import OrderedDict
import mechanize


## we extract texts, id attribute, name attribute, and value attribute  inside input, select, and button elements

def inputfromprefiltered():
    dictpre1 = {}
    file1 = open(
        '../../Get prefiltered URLs/forth_iteration/getcontenturl.csv',
        'r')
    csv_reader1 = csv.reader(file1)
    for row in csv_reader1:
        dictpre1[','.join(row)] = 0

    dicturlpre = {}
    for i in range(1,7):
        file1 = open(
            '../../Get prefiltered URLs/forth_iteration/urlcontent'
        +str(i)+'.csv',
            'r')
        csv_reader1 = csv.reader(file1)
        for row in csv_reader1:
            if (','.join(row).split(',|zsy|')[0] in dictpre1):
                dicturlpre[','.join(row).split(',|zsy|')[0]] = [','.join(row), '']

        for key in dicturlpre:
            str1 = ''
            # print(dicturlpre)
            for li in ['input', 'select', 'button']:
                title = re.findall(r'\|zsy\|' + li + '-text:(.*?),\|zsy\|', dicturlpre[key][0].lower(), re.S | re.M)
                if (title):
                    str1 += ' ' + title[0]
                title = re.findall(r'\|zsy\|' + li + '-id:(.*?),\|zsy\|', dicturlpre[key][0].lower(), re.S | re.M)
                if (title):
                    str1 += ' ' + title[0]
                title = re.findall(r'\|zsy\|' + li + '-name:(.*?),\|zsy\|', dicturlpre[key][0].lower(), re.S | re.M)
                if (title):
                    str1 += ' ' + title[0]
                title = re.findall(r'\|zsy\|' + li + '-value:(.*?),\|zsy\|', dicturlpre[key][0].lower(), re.S | re.M)
                if (title):
                    str1 += ' ' + title[0]
            dicturlpre[key][1] = str1.replace('\n', ' ').replace('\t', ' ')

        file2 = open('predictLGinput'+str(i)+'.csv', 'w')
        for key in dicturlpre:
            file2.writelines(key + ',|zhuangshuying|' + dicturlpre[key][1] + '\n')




def extract():
    dictpre1 = {}
    file1 = open('../../Get prefiltered URLs/forth_iteration/getcontenturl.csv', 'r')
    csv_reader1 = csv.reader(file1)
    for row in csv_reader1:
        dictpre1[','.join(row)] = 0




    dicturlpre = {}
    csv.field_size_limit(500 * 1024 * 1024)
    for i in range(1, 7):
        file1 = open(
            'predictLGinput' + str(i) + '.csv', 'r')
        csv_reader1 = csv.reader(file1)
        for row in csv_reader1:
            if(','.join(row).split(',|zsy|')[0] in dictpre1):
                dicturlpre[','.join(row).split(',|zsy|')[0]] = [','.join(row),'']


    for key in dicturlpre:
        str1 = ''
        # print(dicturlpre)
        for li in ['input', 'select', 'button']:
            title = re.findall(r'\|zsy\|' + li + '-text:(.*?),\|zsy\|', dicturlpre[key][0].lower(), re.S | re.M)
            if (title):
                str1 += ' ' + title[0]
            title = re.findall(r'\|zsy\|' + li + '-id:(.*?),\|zsy\|', dicturlpre[key][0].lower(), re.S | re.M)
            if (title):
                str1 += ' ' + title[0]
            title = re.findall(r'\|zsy\|' + li + '-name:(.*?),\|zsy\|', dicturlpre[key][0].lower(), re.S | re.M)
            if (title):
                str1 += ' ' + title[0]
            title = re.findall(r'\|zsy\|' + li + '-value:(.*?),\|zsy\|', dicturlpre[key][0].lower(), re.S | re.M)
            if (title):
                str1 += ' ' + title[0]
        dicturlpre[key][1] = str1.replace('\n', ' ').replace('\t', ' ')


    file2 = open('predictLGinput.csv', 'w')
    for key in dicturlpre:
        file2.writelines(key+',|zhuangshuying|'+dicturlpre[key][1]+'\n')


#extract title
def meargetitle():

    dictpre1 = {}
    csv.field_size_limit(500 * 1024 * 1024)
    file1 = open('../../Get prefiltered URLs/forth_iteration/getcontenturl.csv', 'r')
    csv_reader1 = csv.reader(file1)
    for row in csv_reader1:
        # 0表示没有内容
        dictpre1[','.join(row)] = 0

    file=open('predictLGtitle.csv','w')
    for i in range(1, 7):
        file1 = open(
            '../../Get prefiltered URLs/forth_iteration/urlcontent'+str(i)+'.csv','r')
        csv_reader1 = csv.reader(file1)
        for row in csv_reader1:
            try:
                html=','.join(row).split(',|zhuangshuying|')[2]
                url=','.join(row).split(',|zhuangshuying|')[0]
                title = re.findall(r'<title>(.*?)<\/title>', html.lower(), re.S | re.M)
                if (title and  url in dictpre1):
                    dictpre1[url]=title[0]
            except IndexError as e:
                continue

    for key in dictpre1:
        file.writelines(key + ',|zhuangshuying|' + dictpre1[key] + '\n')


def titlepluscontrol(f1name,f2name,f3name,f4name):
    keylist={}
    file1 = open(f1name, 'r')
    csv_reader1 = csv.reader(file1)
    for row in csv_reader1:
        if (','.join(row) not in keylist):
            keylist[','.join(row)] = 0
    print(len(keylist))
    dictisLG = {}
    csv.field_size_limit(500 * 1024 * 1024)
    file1 = open(f2name, 'r')
    csv_reader1 = csv.reader(file1)
    for row in csv_reader1:
        if(','.join(row).split(',|zhuangshuying|')[0] in keylist and ','.join(row).split(',|zhuangshuying|')[1].replace(' ','')!=''):
            dictisLG[','.join(row).split(',|zhuangshuying|')[0]]=','.join(row).split(',|zhuangshuying|')[1]
    file1 = open(f3name, 'r')
    csv_reader1 = csv.reader(file1)
    for row in csv_reader1:
        if (','.join(row).split(',|zhuangshuying|')[0] in keylist and ','.join(row).split(',|zhuangshuying|')[1].replace(' ','')!=''):
            if(','.join(row).split(',|zhuangshuying|')[0] in dictisLG):
                dictisLG[','.join(row).split(',|zhuangshuying|')[0]] += ' '+','.join(row).split(',|zhuangshuying|')[1]
            else:
                dictisLG[','.join(row).split(',|zhuangshuying|')[0]] = ','.join(row).split(',|zhuangshuying|')[1]
    print(len(dictisLG))
    file2=open(f4name,'w')
    for key in dictisLG:
        file2.writelines(key+',|zhuangshuying|'+dictisLG[key]+'\n')

if __name__ == '__main__':
    inputfromprefiltered()
    extract()
    meargetitle()
    titlepluscontrol('../../Get prefiltered URLs/forth_iteration/getcontenturl.csv','predictLGtitle.csv','predictLGinput.csv','predictLGtitleplusinput.csv')
