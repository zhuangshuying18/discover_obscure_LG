##爬取traceroute.org
import urllib.request
import requests
import threading
from bs4 import BeautifulSoup as bs
import re
import json
import csv
def crawling():
    dictasorg={}
    file1 = open('../peeringdb/AS-Org/AS-ORG.csv', 'r')
    csv_reader1 = csv.reader(file1)
    for row in csv_reader1:
        ##ASN AS_name orgname
        dictasorg[row[0].split('|')[0]] = [row[0].split('|')[1],row[0].split('|')[2]]


    newdict={}

    url="http://www.traceroute.org/#Looking%20Glass"
    opener = urllib.request.build_opener()
    data = opener.open(url)
    print('当前地址：' + str(data.geturl()))
    code = data.read().decode('utf-8')

    soup = bs(code, "html.parser")
    urls = soup.find_all(name='a', attrs={'href': re.compile(('.'))})

    tag=0
    for url in urls:
        if('GARR (AS137)') in url:
            tag=1
        if('The NetLantis Project Route Server' in url):
            tag=0

        if(tag==1):
            ##deal URL
            print(url)
            matchobj=re.match(r'<a href=\"(.*?)\" target=(.*?)>(.*?)</a>',str(url))
            if matchobj:
                # print(matchobj.group(1)+','+matchobj.group(3)+'\n')
                orgname=matchobj.group(3)
                asname=-1
                if('(' in matchobj.group(3)):
                    orgname=orgname.split(' (')[0]
                    try:
                        asname=int(matchobj.group(3).split(' (')[1].split(')')[0][2:])
                    except ValueError as e:
                        continue


                ###if we have as-org information from CAIDA, record it
                if(str(asname) in dictasorg):
                    newdict[orgname]=[asname,matchobj.group(1),dictasorg[str(asname)][0],dictasorg[str(asname)][1]]
                else:
                    newdict[orgname]=[asname,matchobj.group(1),"",""]
    print(len(newdict))
    with open("LGlist.json","w") as f:
        json.dump(newdict,f)


if __name__ == '__main__':
    crawling()