import urllib.request
import ssl
import re
import csv
import json
from bs4 import BeautifulSoup as bs
def crawling():
    dictasorg = {}
    file1 = open('AS-ORG.csv', 'r')
    csv_reader1 = csv.reader(file1)
    for row in csv_reader1:
        ##ASN AS_name orgname
        dictasorg[row[0].split('|')[0]] = [row[0].split('|')[1], row[0].split('|')[2]]


    context = ssl._create_unverified_context()
    url = 'https://www.bgp4.as/looking-glasses'
    request = urllib.request.Request(url)
    response = urllib.request.urlopen(url=request, context=context)
    code=response.read().decode('utf-8')
    print(code)
    soup = bs(code, "html.parser")
    urls = soup.find_all(name='a', attrs={'href': re.compile(('.'))})
    asname=-1
    orgname=''
    lgurl=''
    newdict={}
    i=0
    for url in urls:
        print(url)
        ##<a href="http://lg.bt.net/" target="eubtglobal.1" title="BT Global Services BGP Looking Glass (AS5400)">BT Global Services Looking Glass</a>
        matchobj = re.match(r'<a href=\"(.*?)\" target=(.*?)title=\"(.*?)\">(.*?)</a>', str(url))
        if(matchobj):
            if('Looking Glass' in matchobj.group(4)):
                i=0
                orgname=matchobj.group(4).replace("Looking Glass",'').strip()
                lgurl=matchobj.group(1)
            if(i==2 and 'AS' in matchobj.group(4)):
                asname=int(matchobj.group(4)[2:])
                if (str(asname) in dictasorg):
                    newdict[orgname] = [asname,lgurl, dictasorg[str(asname)][0], dictasorg[str(asname)][1]]
                else:
                    newdict[orgname] = [asname, lgurl, "", ""]
            i+=1
    print(len(newdict))
    with open("LGlist.json","w") as f:
        json.dump(newdict,f)


if __name__ == '__main__':
    crawling()