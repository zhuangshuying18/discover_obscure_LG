import os
import threading
import datetime
import os
import time
import sys
import pycurl
import csv
import json

def dealpeeringdb():
    dictasorg={}
    file1 = open('./AS-Org/AS-ORG.csv', 'r')
    csv_reader1 = csv.reader(file1)
    for row in csv_reader1:
        ##ASN AS_name orgname
        dictasorg[row[0].split('|')[0]] = [row[0].split('|')[1],row[0].split('|')[2]]



    newdict={}
    f = open('peeringdbnet.json', encoding='utf-8')  # 打开‘json文件
    res = f.read()  # read file
    data=json.loads(res)
    for key in data['data']:
        print(key)
        if(key['looking_glass']!=''  ):
            if( str(key['asn']) in dictasorg):
                newdict[key['name']]=[key['asn'],key['looking_glass'],dictasorg[str(key['asn'])][0],dictasorg[str(key['asn'])][1]]
            else:
                newdict[key['name']]=[key['asn'],key['looking_glass'],"",""]

    with open("LGlist.json","w") as f:
        json.dump(newdict,f)




if __name__ == '__main__':
    dealpeeringdb()

