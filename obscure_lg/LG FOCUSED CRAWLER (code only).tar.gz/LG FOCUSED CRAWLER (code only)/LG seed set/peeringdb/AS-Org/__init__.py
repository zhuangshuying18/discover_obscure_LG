

def deal():
    file_context = open("20200401.as-org2info.txt", 'r').read().splitlines()
    leng = len(file_context)
    tag1=0
    tag2=0
    dict1={}
    dict2={}
    for i in range(0, leng):
        if("# format:org_id|changed|org_name|country|source" in file_context[i]):
            tag1=1
            continue
        if ("# format:aut|changed|aut_name|org_id|opaque_id|source" in file_context[i]):
            tag2 = 1
            continue
        if(tag1==1 and tag2==0):
            dict1[file_context[i].split('|')[0]]=[file_context[i].split('|')[2],file_context[i].split('|')[3]]
        elif(tag1==1 and tag2==1):
            dict2[file_context[i].split('|')[0]]=[file_context[i].split('|')[2],file_context[i].split('|')[3]]

    file=open("AS-ORG.csv",'w')
    for key in dict2:
        if(dict2[key][1] in dict1):
            ##ASN  aut_name orgname country
            file.writelines(key+'|'+dict2[key][0]+'|'+dict1[dict2[key][1]][0]+'|'+dict1[dict2[key][1]][1]+'\n')



if __name__ == '__main__':
    deal()
