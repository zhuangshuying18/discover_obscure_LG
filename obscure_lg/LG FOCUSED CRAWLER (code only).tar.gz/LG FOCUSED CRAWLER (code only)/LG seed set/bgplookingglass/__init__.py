import urllib.request
import requests
import threading
from bs4 import BeautifulSoup as bs
import re
import json
import pandas as pd
import csv
def crawling():
    for table in pd.read_html('http://www.bgplookingglass.com'):
        table.to_csv('table.csv', mode='a', encoding='utf-8', header=0, index=False)

def deal():
    dictasorg = {}
    file1 = open('../peeringdb/AS-Org/AS-ORG.csv', 'r')
    csv_reader1 = csv.reader(file1)
    for row in csv_reader1:
        ##ASN AS_name orgname
        dictasorg[row[0].split('|')[0]] = [row[0].split('|')[1], row[0].split('|')[2]]

    newdict={}
    file1 = open('table.csv', 'r')
    csv_reader1 = csv.reader(file1)
    i=0
    for row in csv_reader1:
        i+=1
        if(i>2):
            orgname=row[0].replace('Looking Glass ',"")
            asname=int(row[1])
            orgname=orgname.replace('AS'+str(asname),"")
            orgname=orgname.strip()
            print(orgname)
            #if we have as-org information from CAIDA, record it
            if (str(asname) in dictasorg):
                newdict[orgname] = [asname, row[2], dictasorg[str(asname)][0], dictasorg[str(asname)][1]]
            else:
                newdict[orgname] = [asname, row[2], "", ""]
    print(len(newdict))
    with open("LGlist.json", "w") as f:
        json.dump(newdict, f)
##ASN AS_name orgname
if __name__ == '__main__':
    # crawling()
    deal()


